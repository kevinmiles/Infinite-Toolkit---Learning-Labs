var sendJSONresponse = function(res, status, content) {
  res.status(status);
  res.json(content);
};

var fs = require("fs");

try {
    var content;
    if (process.env.NODE_ENV === 'development') {
        content = fs.readFileSync('./.portals_dev.json');
    } else {
        content = fs.readFileSync('./.portals_prod.json');
    }
    sandboxes = JSON.parse(content);
} catch (err) {
    if (err.code === 'ENOENT') {
        console.log('File not found .portals.json !');
        throw err;
    } else {
        throw err;
    }
}
     
console.log("Declared portals : \n"+ content);
sandboxes = JSON.parse(content);

module.exports.sandboxes = function(req, res) {
    console.log(" Sandbox from server : "+JSON.stringify(sandboxes,null,2));
    sendJSONresponse(res, 200, sandboxes);
};
