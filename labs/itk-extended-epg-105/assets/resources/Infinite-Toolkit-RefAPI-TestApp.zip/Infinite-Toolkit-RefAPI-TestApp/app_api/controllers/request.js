var rest = require("restler");

var sendJSONresponse = function(res, status, content) {
	res.status(status);
	res.json(content);
};



module.exports.channels = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" channels requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "channels" + req.body.param;
	console.log("Received in channels server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log(" error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.categories = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" categories requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "categories";
	console.log("Received in categories server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});
};



module.exports.fillSubCategories = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "fillSubCategories requestUrl parameter required"
		});
		console.log("fillSubCategories requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "categories/"+req.body.data;
	console.log("Received in fillSubCategories server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.agggrid = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" agggrid requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "agg/grid" + req.body.param;
	console.log("Received in agggrid server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));
	// console.log("Received param :"+ JSON.stringify(req.body.param,null,2));


	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		//console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.aggcontent = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" aggcontent requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "agg/content" + req.body.param;
	console.log("Received in aggcontent server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
//		console.log("response : "+JSON.stringify(response));
		sendJSONresponse(res, response.statusCode, error);
	});
};


module.exports.aggplanner = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: " requestUrl parameter required"
		});
		console.log("aggplanner requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+"agg/library/planner"+ req.body.param;


	console.log("Received in aggplanner server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));


	if(req.body.method ==="GET") 
	{
		rest.get(requestUrl, { headers: req.body.headers })
		.on("success", function(response){
			console.log(" response : "+JSON.stringify(response, null, 2));
			sendJSONresponse(res, 200, response);
		}).on("fail", function(error, response){
			console.log("error : "+JSON.stringify(error, null, 2));
			sendJSONresponse(res, response.statusCode, error);
		});
	}


};


module.exports.aggbookings = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" aggbookings requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+"agg/library/bookings";


	console.log("Received in aggbookings server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));


	if(req.body.method ==="GET") 
	{
		rest.get(requestUrl, { headers: req.body.headers })
		.on("success", function(response){
			console.log(" response : "+JSON.stringify(response, null, 2));
			sendJSONresponse(res, 200, response);
		}).on("fail", function(error, response){
			console.log("error : "+JSON.stringify(error, null, 2));
			sendJSONresponse(res, response.statusCode, error);
		});
	}


	if(req.body.method ==="DELETE") 
	{
		console.log("calling rest.del booking with proxy : "+req.body.data);
		rest.del(requestUrl+"/"+req.body.data, { headers: req.body.headers })
		.on("success", function(response){
			console.log("DELETE BOOKING response : "+JSON.stringify(response, null, 2));
			sendJSONresponse(res, 200, response);
		}).on("fail", function(error, response){
			console.log("DELETE BOOKING error : "+JSON.stringify(error, null, 2));
			sendJSONresponse(res, response.statusCode, error);
		});
	};


};





module.exports.platform = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "platform requestUrl parameter required"
		});
		console.log("platform requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "platform" + req.body.param;
	console.log("Received in platform server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
//		console.log("response : "+JSON.stringify(response));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.getUserprofiles = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "userprofiles requestUrl parameter required"
		});
		console.log("userprofiles requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "userprofiles" + req.body.param;
	console.log("Received in aggbookings server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
//		console.log("response : "+JSON.stringify(response));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.fillFavoriteChannels = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "userprofiles requestUrl parameter required"
		});
		console.log("userprofiles requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "userprofiles/"+req.body.data+"/settings/favoriteChannels";
	console.log("Received in aggbookings server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.fillUserprofile = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "fillUserprofile requestUrl parameter required"
		});
		console.log("fillUserprofile requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "userprofiles/"+req.body.data+"/settings";
	console.log("Received in aggbookings server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		console.log(" response : "+JSON.stringify(response, null, 2));
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log("error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});
};

module.exports.playsessions = function(req, res) {

	//console.log("==> PLAY SESSION  : "+JSON.stringify(req, null, 2));

	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" aggbookings requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl;

	if(req.body.method ==="DELETE") {
		console.log("Received in delete session server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));
		//console.log("calling rest.del session with proxy for session ID: "+req.body.data);

		rest.del(requestUrl+"/"+req.body.data, { headers: req.body.headers })
		.on("success", function(response){
			console.log("DELETE SESSION response : "+JSON.stringify(response, null, 2));
			sendJSONresponse(res, 200, response);
		}).on("fail", function(error, response){
			console.log("DELETE SESSION error : "+JSON.stringify(error, null, 2));
			sendJSONresponse(res, response.statusCode, error);
		});
	}
	if(req.body.method ==="POST") {

		console.log("Received in play session server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers,null,2));

		rest.post(requestUrl, { headers: req.body.headers })
		.on("success", function(response){
			console.log(" response : "+JSON.stringify(response, null, 2));
			sendJSONresponse(res, 200, response);
		}).on("fail", function(error, response){
			console.log("error : "+JSON.stringify(error, null, 2));
			sendJSONresponse(res, response.statusCode, error);
		});

	}



};



module.exports.getHousehold = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" household requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "household/me";
	console.log("Received in household server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers, null, 2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log(" error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});


};

module.exports.getHouseholdDevices = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" household requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "household/me/devices";
	console.log("Received in household server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers, null, 2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log(" error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});


};

module.exports.getHyperMetadata = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" getHyperMetadata requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl+ "hypermetadata";
	console.log("Received in getHyperMetadata server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers, null, 2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log(" error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});


};

module.exports.getPersonalMetadata = function(req, res) {
	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "requestUrl parameter required"
		});
		console.log(" getPersonalMetadata requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl + "personalmetadata";
	console.log("Received in getPersonalMetadata server side urlRequest : "+requestUrl+" headers :"+ JSON.stringify(req.body.headers, null, 2));

	rest.get(requestUrl, { headers: req.body.headers })
	.on("success", function(response){
		sendJSONresponse(res, 200, response);
	}).on("fail", function(error, response){
		console.log(" error : "+JSON.stringify(error, null, 2));
		sendJSONresponse(res, response.statusCode, error);
	});


};

module.exports.bookRecordfromGrid = function(req, res) {

	if (!req.body.requestUrl) {
		sendJSONresponse(res, 400, {
			message: "bookRecordfromGrid parameter required"
		});
		console.log(" bookRecordfromGrid requestURL not found.");
		return;
	}

	var requestUrl = req.body.requestUrl;
	var headers = req.body.headers;
	var data = {"bookingType": req.body.bookingType,   
			"conflictDetectOption": req.body.conflictDetectOption,                
			"contentInstanceId": req.body.contentInstanceId,
			"targetDevices": req.body.targetDevices
	};
	rest.post(requestUrl, {headers: req.body.headers,
		//stringify object as per restler suggestion
		data: JSON.stringify(data,null,2)})
		.on("success", function(response){
			console.log(" response : "+JSON.stringify(response, null, 2));
			sendJSONresponse(res, 200, response);

		}).on("fail", function(error, response){
			console.log("error : "+JSON.stringify(error, null, 2));
//			console.log("response : "+JSON.stringify(response));
			sendJSONresponse(res, response.statusCode, error);
		});
};
