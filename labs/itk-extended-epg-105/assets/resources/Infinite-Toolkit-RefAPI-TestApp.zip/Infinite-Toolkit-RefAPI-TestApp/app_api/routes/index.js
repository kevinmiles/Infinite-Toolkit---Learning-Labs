var express = require("express");
var router = express.Router();

var ctrlAuth = require("../controllers/authentication");
var ctrlSettings = require("../controllers/settings");
var ctrlRequest = require("../controllers/request");

// test
router.get("/hello", function(req, res) {
	res.status(200);
	res.json({message: "fine"});
});

// request
router.post("/channels", ctrlRequest.channels);

// request
router.post("/categories", ctrlRequest.categories);
router.post("/categories/fillSubCategories", ctrlRequest.fillSubCategories);


// request
router.post("/agg/grid", ctrlRequest.agggrid);

// request
router.post("/agg/library/planner", ctrlRequest.aggplanner);
router.post("/agg/library/bookings", ctrlRequest.aggbookings);

// request
router.post("/devices/me/playsessions", ctrlRequest.playsessions);

// request
router.post("/agg/content", ctrlRequest.aggcontent);

// request
router.post("/platform", ctrlRequest.platform);

// request
router.post("/userprofiles/getUserprofiles", ctrlRequest.getUserprofiles);
router.post("/userprofiles/fillUserprofile", ctrlRequest.fillUserprofile);
router.post("/userprofiles/fillFavoriteChannels", ctrlRequest.fillFavoriteChannels);

// authentication
router.post("/login", ctrlAuth.login);

// authentication
router.get("/has/default", ctrlAuth.hasDefault);

// settings
router.get("/sandboxes", ctrlSettings.sandboxes);

// hypermetadata
router.post("/hypermetadata/getHyperMetadata", ctrlRequest.getHyperMetadata);
router.post("/personalmetadata/getPersonalMetadata", ctrlRequest.getPersonalMetadata);

// household
router.post("/household/getHousehold", ctrlRequest.getHousehold);
router.post("/household/getHouseholdDevices", ctrlRequest.getHouseholdDevices);

// request
router.post("/agg/library/performBookingsFromGrid", ctrlRequest.bookRecordfromGrid);

module.exports = router;
