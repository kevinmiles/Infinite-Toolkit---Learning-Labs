(function(){

  angular
  .module('InfiniteEPG')
  .service('categories', cats);

  cats.$inject = ["$http", "authentication", "settings"];   
  function cats($http, authentication, settings) {
        
      var listCategories = function(){
          if(settings.getCurrentSandbox().proxy === false){
              return $http.get(settings.getCurrentSandbox().url + "categories",  {
                  headers: {
                      Authorization: "Bearer "+authentication.getAccessToken()
                  }
              });
          } else {
              return authentication.categories(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers );
          }
      };


      var fillSubCategories = function(categoryId){
          if(settings.getCurrentSandbox().proxy === false){
              return $http.get(settings.getCurrentSandbox().url + "categories/"+categoryId,  {
                  headers: {
                      Authorization: "Bearer "+authentication.getAccessToken()
                  }
              });
          } else {
              return authentication.fillSubCategories(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, categoryId);
          }
      };

      
   return {
     listCategories : listCategories,
     fillSubCategories : fillSubCategories,
   };


   
 }
})();
