(function(){

	angular
	.module('InfiniteEPG')
	.service('devices', devices);

	devices.$inject = ["$http", "authentication", "settings"];   
	function devices ($http, authentication, settings) {

		var getPlaySession = function(queryParams){
			var playSessionRequest=	settings.getCurrentSandbox().url+"devices/me/playsessions";
			playSessionRequest+="?"+queryParams;
			console.log("playSessionRequest:"+playSessionRequest);

			if(!settings.getCurrentSandbox().proxy){
				return $http.post(playSessionRequest,  "",
						{
					headers: settings.getSandboxHeaders()
						}
				);		
			} else {
				return authentication.playsessions(playSessionRequest, settings.getCurrentSandbox().headers);
			}

		};

		var deleteSession = function(id){
			var deleteSessionRequest=	settings.getCurrentSandbox().url+"devices/me/playsessions";
			if(!settings.getCurrentSandbox().proxy){				
				return $http.delete(deleteSessionRequest+"/"+id,  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					}
				}
				);
			} else {
				return authentication.deletesessions(deleteSessionRequest, settings.getCurrentSandbox().headers,id);
			}

		};		


		return {
			getPlaySession : getPlaySession,
			deleteSession : deleteSession,

		};
	}
})();