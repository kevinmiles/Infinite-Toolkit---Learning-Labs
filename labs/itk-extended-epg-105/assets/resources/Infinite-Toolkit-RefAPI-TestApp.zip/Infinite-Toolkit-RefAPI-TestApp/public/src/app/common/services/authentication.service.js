(function() {
	angular
	.module("InfiniteEPG")
	.service("authentication", authentication);

	authentication.$inject = ["$window", "$http", "$rootScope"];
	
	
	function serializeData( data ) { 
	    // If this is not an object, defer to native stringification.
	    if ( ! angular.isObject( data ) ) { 
	        return( ( data == null ) ? "" : data.toString() ); 
	    }

	    var buffer = [];

	    // Serialize each key in the object.
	    for ( var name in data ) { 
	        if ( ! data.hasOwnProperty( name ) ) { 
	            continue; 
	        }

	        var value = data[ name ];

	        buffer.push(
	            encodeURIComponent( name ) + "=" + encodeURIComponent( ( value == null ) ? "" : value )
	        ); 
	    }

	    // Serialize the buffer and clean it up for transportation.
	    var source = "?"+buffer.join( "&" ).replace( /%20/g, "+" ); 
	    return( source ); 
	}
	
	function authentication($window, $http, $rootScope, $q) {

		var saveDirectaccess = function(directaccess) {
			if ( $window.localStorage["directAccess"] != directaccess ) {
				$window.localStorage["directAccess"] = JSON.stringify(directaccess);
				notify();
			}
		};

		var getDirectaccess = function() {
			var t = $window.localStorage["directAccess"];
			if (t){
				return JSON.parse(t);
			}
		};

		var isDirectAccess = function() {

			var directaccesskey = getDirectaccess();
			if (directaccesskey) {
				return directaccesskey.directaccess;
			} else {
				return false;
			}
		};

		var saveToken = function(token) {
			token.exp = Date.now()/1000 + token.expires_in;
			$window.localStorage["InfiniteEPG-token"] = JSON.stringify(token);
		};

		var getToken = function() {
			var t = $window.localStorage["InfiniteEPG-token"];
			if (t){
				return JSON.parse(t);
			}
		};

		var getAccessToken = function(){
			var t = getToken();

			return t?getToken().access_token:"";
		}

		var login = function(credentials) {
			console.log(" Credentials :"+JSON.stringify(credentials));
			return $http.post("api/login", credentials).then(function(response) {
				saveToken(response.data);
				notify();
			});
		};

		var channels = function(requestUrl, headers, query) {
			return $http.post("api/channels", { requestUrl : requestUrl, headers : headers, param : serializeData(query) }).then(function(response) {
				return response;
			});
		};

		var categories = function(requestUrl,headers) {
			return $http.post("api/categories", { requestUrl : requestUrl, headers : headers }).then(function(response) {
				return response;
			});
		};


		var fillSubCategories = function(requestUrl, headers, categoryId) {
			return $http.post("api/categories/fillSubCategories", { requestUrl : requestUrl, headers : headers, data : categoryId }).then(function(response) {
				return response;
			});
		};

		
		
		var fillBookingsFromPlanner = function(requestUrl, headers, query) {
			return $http.post("api/agg/library/planner", { requestUrl : requestUrl, headers : headers, method : "GET" , param : serializeData(query)}).then(function(response) {
				return response;
			});
		};

		var deleteBooking = function(requestUrl, headers,bookingId) {
			return $http.post("api/agg/library/bookings", { requestUrl : requestUrl, headers : headers, method : "DELETE",  data : bookingId }).then(function(response) {
				return response;
			});
		};

		var grid = function(requestUrl, headers, query) {
			return $http.post("api/agg/grid", { requestUrl : requestUrl, headers : headers, param : serializeData(query) }).then(function(response) {
				return response;
			});
		};

		var getHousehold = function(requestUrl, headers) {
			return $http.post("api/household/getHousehold", { requestUrl : requestUrl, headers : headers }).then(function(response) {
				return response;
			});
		};

		var getHouseholdDevices = function(requestUrl, headers) {
			return $http.post("api/household/getHouseholdDevices", { requestUrl : requestUrl, headers : headers }).then(function(response) {
				return response;
			});
		};

		var content = function(requestUrl, headers, query) {
			return $http.post("api/agg/content", { requestUrl : requestUrl, headers : headers, param : serializeData(query) }).then(function(response) {
				return response;
			});
		};

		var playsessions = function(requestUrl, headers, instanceID) {
			return $http.post("api/devices/me/playsessions", { requestUrl : requestUrl, headers : headers, method : "POST" , data : instanceID}).then(function(response) {
				return response;
			}, function(error){
				console.error("playsessions error:"+error.status+' / '+error.statusTextr);
				return error;
			});
		};

		var deletesessions = function(requestUrl, headers, instanceID) {
			return $http.post("api/devices/me/playsessions", { requestUrl : requestUrl, headers : headers, method : "DELETE",  data : instanceID }).then(function(response) {
				return response;
			});
		};
		
		
		
		var platform = function(requestUrl, headers ) {
			return $http.post("api/platform", { requestUrl : requestUrl, headers : headers }).then(function(response) {
				return response;
			});
		};

		var getUserprofiles = function(requestUrl, headers, query) {
			return $http.post("api/userprofiles/getUserprofiles", { requestUrl : requestUrl, headers : headers , param : serializeData(query) }).then(function(response) {
				return response;
			});
		};

		var fillUserprofile = function(requestUrl, headers, profileId) {						
			return $http.post("api/userprofiles/fillUserprofile", { requestUrl : requestUrl, headers : headers, data : profileId }).then(function(response) {
				return response;
			});
		};

		var fillFavoriteChannels = function(requestUrl, headers, profileId) {
			return $http.post("api/userprofiles/fillFavoriteChannels", { requestUrl : requestUrl, headers : headers, data : profileId }).then(function(response) {
				return response;
			});
		};

		
		var bookRecordfromGrid = function(requestUrl, headers, content) {
			var headers = {'Content-Type': 'application/json','x-cisco-vcs-identity':headers['x-cisco-vcs-identity']};
			var req = {
					method: 'POST',
					url: "api/agg/library/performBookingsFromGrid",
					data: { requestUrl:requestUrl,headers: headers,contentInstanceId: content.id,bookingType: content.type,
						conflictDetectOption: 'none',targetDevices: ['cDVR']}};
			return $http(req).then(function(response){return response.body});
		};

		var logout = function(){
			$window.localStorage.removeItem("InfiniteEPG-token");
			notify();
		};

		var isLoggedIn = function() {

			var token = getToken();
			if (token) {
				return token.exp > Date.now() / 1000;
			} else {
				return false;
			}
		};

		var currentUser = function() {
			if (isLoggedIn()) {
				var token = getToken();
				return {
					client_id: token.client_id,
				};
			}
		};

		var notify = function(){
			$rootScope.$emit('auth-service-event');
		};

		var cbs = [], ids = [];
		var cbf = function(){
			cbs.forEach(function(cb){
				cb();
			});
		};


		return {
			subscribe: function(scope, id, callback) {
				if (ids.indexOf(id) >= 0){
					cbs[ids.indexOf(id)] = callback;
					return;
				} else {
					ids.push(id);
					cbs.push(callback);    
				}
				var handler = $rootScope.$on('auth-service-event', cbf);
				scope.$on('$destroy', handler);
			},
			saveDirectaccess : saveDirectaccess,
			getDirectaccess : getDirectaccess,
			isDirectAccess : isDirectAccess,
			notify: notify,
			saveToken: saveToken,
			getToken: getToken,
			getAccessToken: getAccessToken,
			login: login,
			channels : channels,
			platform : platform,
			getHousehold : getHousehold,
			getHouseholdDevices: getHouseholdDevices,
			categories : categories,
			fillSubCategories : fillSubCategories,
			fillBookingsFromPlanner : fillBookingsFromPlanner,
			bookRecordfromGrid: bookRecordfromGrid,
			deleteBooking : deleteBooking,
			getUserprofiles : getUserprofiles,
			fillUserprofile : fillUserprofile,
			fillFavoriteChannels : fillFavoriteChannels,
			grid : grid,
			content : content,
			playsessions : playsessions,
			deletesessions : deletesessions,
			logout: logout,
			isLoggedIn: isLoggedIn,
			currentUser: currentUser,
		};
	}
})();
