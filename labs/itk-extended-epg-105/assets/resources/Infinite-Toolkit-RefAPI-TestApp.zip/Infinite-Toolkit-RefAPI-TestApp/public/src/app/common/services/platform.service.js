(function(){

  angular
  .module('InfiniteEPG')
  .service('platform', platform);

  platform.$inject = ["$http", "authentication", "settings"];   
  function platform ($http, authentication, settings) {

          var getPlatform = function(query){
              if(!settings.getCurrentSandbox().proxy){
                  return $http.get(settings.getCurrentSandbox().url + "platform",  {
                      headers: {
                          Authorization: "Bearer "+authentication.getAccessToken()
                      },
                      params: query
                  });
              } else {
                  return authentication.platform(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers);
              }
          };
      
      return {
    	  getPlatform : getPlatform,
      };
 }
})();


