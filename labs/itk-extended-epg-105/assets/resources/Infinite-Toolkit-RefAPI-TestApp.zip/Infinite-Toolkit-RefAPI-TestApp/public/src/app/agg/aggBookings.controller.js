((function(){

	angular.module('InfiniteEPG').controller('aggBookingsCtrl', aggBookingsCtrl);
	aggBookingsCtrl.$inject = ['$scope', '$routeParams', 'agg', 'settings', '$http', '$location'];


	function aggBookingsCtrl($scope, $routeParams, agg, settings, $http, $location) {
		var vm = this;

		vm.query = {
				limit: 8
		};

		vm.bookings = [];
		var currentOffset = 0;


		vm.getBookings = function(reset){
			if (reset){
				vm.bookings = [];
				currentOffset = 0;
				vm.total = 0;
			}else {
				if (vm.bookings.length >= vm.total){return;}
			}

			vm.rawData = null;
			vm.error = null;
			vm.busy = true;
			vm.query.offset = currentOffset;
			vm.query.limit = vm.total?Math.min(vm.query.limit, vm.total - currentOffset):vm.query.limit;

			function processResponse(response) {
				var queryContent = response.data.content;
				vm.count = response.data.count;
				vm.total = response.data.total;

				for (var i = 0; i < queryContent.length; i++) {
					vm.bookings.push(queryContent[i]);
				}
				vm.rawData = response.data;
				currentOffset = vm.bookings.length;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}


			if(!vm.useDummyJson) {
				console.log("Send query to sanbox:"+vm.query)
				agg.fillBookingsFromPlanner(vm.query).then(
						function(response){
							processResponse(response);
						}, function(error){
							processError(error);
						}
				);

			} else {
				console.log("Use dummy Json:");
				$http.get('src/app/agg/aggBookingsSample.json').then(
						function(response){
							processResponse(response);
						}, function(error){
							processError(error);
						}
				);

			}
		};
		
		
		settings.subscribe($scope, "bookings", function() {
			vm.getBookings(true);
		});

		vm.playVideo = function(booking){
			// In this implementation, the /video will load the video.template.html page
			// and intanceId=booking.id will be use as query param by devices.service.js
			$location.path("/video/instanceId="+booking.id);
		};		


		vm.deleteBooking = function(booking){
			if(!vm.useDummyJson) {
				console.log("Try to delete booking ID:"+booking.id);
				agg.deleteBooking(booking);
			} else {
				console.log("With dummy Json, can't delete booking ID:"+booking.id);				
			}
		};

	};

})());