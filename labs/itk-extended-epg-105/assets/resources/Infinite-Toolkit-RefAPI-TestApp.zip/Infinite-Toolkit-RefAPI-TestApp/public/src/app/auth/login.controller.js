(function() {
    angular
        .module("InfiniteEPG")
        .controller("loginCtrl", loginCtrl);

    loginCtrl.$inject = ["$location", "authentication", "$http"];
    function loginCtrl($location, authentication, $http) {
        var vm = this;

        vm.pageHeader = {
            title: "Log in Into the Infinite Platform"
        };
        vm.credentials = {
            email: "",
            password: ""
        };

        vm.returnPage = $location.search().page || "/";

        vm.onSubmit = function() {
            vm.formError = "";
            if (!vm.credentials.client_id || !vm.credentials.client_secret) {
                vm.formError = "Tous les champs sont requis, veuillez réessayer";
                return false;
            } else {
                vm.doLogin(vm.credentials);
            }
        };

        $http.get("api/has/default").then(function(response) {
            console.log("Result of Has Default: response ", response);
            if (!response.data.hasDefault) {
                vm.defaultProvided = false;
            } else {
                vm.loginWithDefaultCredentials = function() {
                    vm.doLogin({client_id:"auto", client_secret:"auto"});
                };
                vm.defaultProvided = true;
            }
        });
        
        vm.doLogin = function(credentials) {
            vm.formError = "";
            authentication
                .login(credentials)
                .then(function() {
                    $location.search("page", null);
                    $location.path(vm.returnPage);
                }, function(err) {
                    vm.formError = err.data.error;
                });
        };
    }
})();