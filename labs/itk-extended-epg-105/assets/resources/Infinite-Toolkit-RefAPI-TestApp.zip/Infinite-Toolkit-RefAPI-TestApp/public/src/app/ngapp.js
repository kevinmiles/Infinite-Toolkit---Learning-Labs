(function(){

    angular.module("InfiniteEPG", ["ngRoute", "ngAnimate", "ui.bootstrap", "infinite-scroll"])
    .factory("mySocket", function(socketFactory) {
        return socketFactory();
    });

})();