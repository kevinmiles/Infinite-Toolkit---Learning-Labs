(function() {
    angular
    .module("InfiniteEPG")
    .controller("navigationCtrl", navigationCtrl);

    navigationCtrl.$inject = ["$scope", "$location", "authentication", "settings", "suggest", "pins"];
    function navigationCtrl($scope, $location, authentication, settings, suggest, pins){
        var vm = this;
        
		// A special item is added here to the head-end list in order to have a quick link access
		// to Create / Modify / Delete a existing local head-end.
		// see process in settings.controller
        addQuickLink =   {"name": "Add Modify Head-End", "url": "/headends/", "proxy" : false};

        vm.directAccess = authentication.isDirectAccess();

        var _updateUser = function(){
            vm.isLoggedIn = authentication.isLoggedIn();
            vm.directAccess = authentication.isDirectAccess();
            if (vm.directAccess){
                vm.currentUser = { client_id : "Nobody"};
            }else {
                vm.currentUser = authentication.currentUser();
            }
            vm.showHide = vm.isLoggedIn || vm.directAccess;
            //console.log(" navigation vm.showHide                   : "+vm.showHide);
            //console.log(" navigation vm.directAccess               : "+vm.directAccess);
            //console.log(" vm.currentUser.client_id      : "+vm.currentUser.client_id);
        };

        _updateUser();


        var s = 1000;
        var m = 60*s;
        var h = 60*m;
        var d = 24*h;
        var w = 7*d;
        _getDurationString = function(duration){
            var week = Math.floor(duration / w);
            duration = duration % w;
            var day = Math.floor(duration / d);
            duration = duration % d;
            var hours = Math.floor(duration / h);
            duration = duration % h;
            var mins = Math.floor(duration / m);
            duration = duration % m;
            var secs = Math.floor(duration / s);
            duration = duration % s;

            if (week !== 0){
              return week + (week === 1?" week":" weeks");
            } else if (day !== 0){
              return day + " days";
            } else if (hours !== 0){
              return hours+" hours";
            } else if (mins !== 0){
              return mins+" minutes";
            }
            return secs+" secondes";
        };

        vm.getSuggestions = function(keywords){
            return suggest.getSuggestions(keywords)
            .then(function(response){
            return response.data.suggestions;
      }, function(error){
        console.error("search did not work");
      });
        };

        vm.showPin = function(){
            vm.pinChecked = false;
            pins.getModalPin().result
            .then(function(pinOk) {
                vm.pinChecked = pinOk;
            });
        };

        vm.goToSearchTerm = function(item, model, label, event){
            $location.search("name", item.name);
            $location.path("/content/");
        };

        vm.getTokenLeftTime = function(){
            vm.token = authentication.getToken();
            if (!vm.token){return;}
            var timeLeft = vm.token.exp*1000 - Date.now();
            return _getDurationString(timeLeft);
        };

        vm.currentPath = function() {
            return $location.path();
        };

        vm.logout = function() {
            authentication.logout();
            authentication.saveDirectaccess({ "directaccess" : false});
            vm.directAccess = false;
            vm.showHide = vm.isLoggedIn || vm.directAccess;
            $location.path("/#");
        };

        var _getSandboxes = function(){
            settings.getSandboxes()
            .then(function(response){
               vm.directAccess = authentication.isDirectAccess();
               vm.isLoggedIn = authentication.isLoggedIn();
               console.log(" navigation getSandboxes vm.directAccess    : "+vm.directAccess);
               //console.log(" navigation getSandboxes vm.isLoggedIn      : "+vm.isLoggedIn);
               if( !vm.directAccess ) {
                    vm.sandboxes = response.data;
                } else {
                    vm.sandboxes = response.data;
                    for(var i = vm.sandboxes.length - 1; i >= 0; i--) {
                        console.log("vm.sandboxes : "+vm.sandboxes);
                        if(vm.sandboxes[i].proxy != true) {
                           vm.sandboxes.splice(i, 1);
                        }
                    }

                }
               console.log(" navigation Add quick Link item      : "+addQuickLink.name);
               vm.sandboxes.push(addQuickLink);

               if(!settings.getCurrentSandbox()) {
                   console.log("Get default vm.sandboxes name: "+vm.sandboxes[0].name);
                   settings.setCurrentSandbox(vm.sandboxes[0]);            	   
               }
               vm.currentSandbox = settings.getCurrentSandbox();
               console.log("currentSandbox NAME: "+vm.currentSandbox.name);
               console.log("currentSandbox URL: "+vm.currentSandbox.url);

            }, function(error){
                console.error(error);
            })
        };

        vm.selectSandbox = function(sandbox){
        	
            settings.setCurrentSandbox(sandbox);
            vm.currentSandbox = settings.getCurrentSandbox();
            // command to update head-end list in case a new one has been recently added.
            _getSandboxes();
        };

        _getSandboxes();

        
        authentication.subscribe($scope, "nav", function somethingChanged() {
            _updateUser();
            _getSandboxes();
        });

        
    }
})();
