(function(){
	angular
	.module('InfiniteEPG')
	.controller('videoCtrl', videoCtrl);


	videoCtrl.$inject = ['$scope', '$routeParams', 'devices', 'settings'];
	function videoCtrl($scope, $routeParams, devices, settings) {
		var vm = this;
		vm.id = null;
		var myPlayer = videojs('myVideo');
		var id = myPlayer.id();
		// Make up an aspect ratio
		var aspectRatio = 264/640;
 
		$scope.pageClass = 'video-page';

		vm.playLocator = function(locator){
			console.log("vm.playLocator :"+locator);

			devices.getPlaySession(locator)
			.then(function(response){
				if(response.data.displayMessage) {					
					vm.error = "Could not retrieve playSession from IH server. Consider to log out and log in again. "+response.data.displayMessage;

				} else {

					vm.playSession = response.data;
					console.log("vm.playSession:"+vm.playSession);
					console.log("==> ID:"+vm.playSession.id);
					vm.id=vm.playSession.id;
					var videoToPlay = {"type":"application/x-mpegURL", "src":vm.playSession._links.playUrl.href};
					vm.insertLinkIntoVideoTag(videoToPlay);      

				}

			}, function(error){
				var errString = (error.status && error.statusText)?error.status+" "+error.statusText:error.toString;
				vm.error = "Could not retrieve playSession from IH server. Consider to log out and log in again. "+ errString;
			});
 

		};


		vm.insertLinkIntoVideoTag = function(src){
			if (!src){

				if (vm.videosrc.src.endsWith("m3u8")){
					src = {"type":"application/x-mpegURL", "src":name};
				}else{
					src = {"type":"video/mp4", "src":vm.videosrc.src};
				}
			}
			console.log("==> START Playback Session")
			var player = videojs('myVideo');
			player.src(src);
			player.play();
			vm.videosrc = src;
			resizeVideoJS();

		};

		function resizeVideoJS(){
			var width = document.getElementById(id).parentElement.offsetWidth;
			myPlayer.width(width).height( width * aspectRatio );
		}

		vm.deleteSession = function(){
			if(vm.id !== null) {
				console.log("==> DELETE Player Session ID:"+vm.id)
				var player = videojs('myVideo');
				player.dispose();
				devices.deleteSession(vm.id);
				vm.videosrc = null;
				vm.id=null
			};
		}


		var locator = $routeParams.locator;
		if (locator){
			vm.playLocator(locator);
		} 



		var myPlayer = videojs('myVideo');
		var id = myPlayer.id();
		// Make up an aspect ratio
		var aspectRatio = 264/640; 

		function resizeVideoJS(){
			var width = document.getElementById(id).parentElement.offsetWidth;
			myPlayer.width(width).height( width * aspectRatio );

		}


		$scope.$on('$routeChangeStart', function (event, next, prev) {
			// delete running session when navigating to other page.
			vm.deleteSession();  
		});


		// Then on resize call resizeVideoJS()
		window.onresize = resizeVideoJS;
 
		window.onbeforeunload = function (e) {
			// delete running session if browser is closed.
			var e = e || window.event;
			vm.deleteSession();  
			// confirmPopUp('TRY TO LEAVE EPG ?');

			// For IE and Firefox
			if (e) {
				e.returnValue = 'Leaving the video playback page';
			}

			// For Safari
			return 'Leaving the video playback page';

		};


			function confirmPopUp(text) {
			    $scope.$on('$locationChangeStart', function (event, next, current) {
			        if (next) {
			           // event.preventDefault();
			            MessageService.showConfirmation(
			                text,
			            MessageService.MessageOptions.YES_NO, {
			                'YES': function () {
			                    blockNavigation = false;
			                    $location.url($location.url(next).hash());
			                    $rootScope.$apply();
			                },
			                'NO': function () {
			                    MessageService.clear();
			                    console.log('NO Selected')
			                }
			            });
			        }
			    });
			}

	};

})();
