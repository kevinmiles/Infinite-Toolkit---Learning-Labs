((function(){

	angular.module('InfiniteEPG').controller('userprofilesCtrl', userprofilesCtrl);
	userprofilesCtrl.$inject = ['$scope', '$routeParams', 'userprofiles', 'settings', '$http', '$location'];

	// Function used to get the user profile list
	// calling "/userprofiles" API
	function userprofilesCtrl($scope, $routeParams, userprofiles, settings, $http, $location) {
		var vm = this;

		vm.optionLanguages = [
		                      {
		                    	  "name": "eng"
		                      },
		                      {
		                    	  "name": "por"
		                      },
		                      {
		                    	  "name": "ger"
		                      },
		                      {
		                    	  "name": "fre"
		                      }]

		vm.optionBoolean = [
		                    {
		                    	"name": "true"
		                    },
		                    {
		                    	"name": "false"
		                    }]

		vm.optionCC = [
		               {
		            	   "name": "CC1"
		               },
		               {
		            	   "name": "CC2"
		               }]


		vm.optionPR = [
		               {
		            	   "name": "0"
		               },
		               {
		            	   "name": "4"
		               },
		               {
		            	   "name": "8"
		               },
		               {
		            	   "name": "10"
		               },
		               {
		            	   "name": "12"
		               },
		               {
		            	   "name": "14"
		               },
		               {
		            	   "name": "16"
		               },
		               {
		            	   "name": "18"
		               }]

		vm.query = {};
		vm.userprofiles = [];

		// Values to be changed by post request if Update Profile button is pressed
		vm.selectedDisplayName = '';
		vm.selectedUiLanguage = '';
		vm.selectedAudioLanguage = '';
		vm.selectedSubtitlesLanguage = '';
		vm.selectedPresentSubtitles = '';
		vm.selectedPresentClosedCaptions = '';
		vm.selectedClosedCaptionsTrack = '';
		vm.selectedParentalRatingThreshold='';


		vm.getUserProfiles = function(reset){
			if (reset){
				vm.userprofiles = [];
				vm.userprofilesContent = [];
				vm.total = 0;
			}else {
				if (vm.userprofiles.length >= vm.total){return;}
			}

			vm.rawData = null;
			vm.error = null;
			vm.busy = true;
			vm.updateFlag =false;

			function processResponse(response) {
				var queryContent = response.data;
				console.log("getUserProfiles response  OK:");
				vm.total = response.data.length;

				for (var i = 0; i < queryContent.length; i++) {
					vm.userprofiles.push(queryContent[i]);
					//vm.userprofiles[i].index=i;		
					vm.fillUserProfile(i);
					vm.fillFavoriteChannels(i);

				}


				vm.rawData = response.data;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}


			console.log("Send query getUserProfiles to sanbox:"+vm.query)
			userprofiles.getUserProfiles(vm.query).then(
					function(response){
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

		};


		// Function used to get complementary information about user profile
		// calling "/userprofiles/{userporfile.id}/settings" API
		vm.fillUserProfile = function(userProfileIndex){

			function processResponse(response) {
				var queryContent = response.data;
				console.log("fillUserProfile response OK index:"+userProfileIndex);
				// when answer is received, a new entry "content" 
				// is created and filled in vm.userprofiles model
				vm.userprofiles[userProfileIndex].num=userProfileIndex;
				vm.userprofiles[userProfileIndex].content=[];

				vm.userprofiles[userProfileIndex].content.push(queryContent);
				vm.rawData = response.data;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}

			console.log("Send query fillUserProfile to sanbox:"+vm.userprofiles[userProfileIndex].id);
			userprofiles.fillUserProfile(vm.userprofiles[userProfileIndex]).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

		};

		// Function used to get complementary information about user profile
		// calling "/userprofiles/{userporfile.id}/settings/favoriteChanels" API
		vm.fillFavoriteChannels = function(userProfileIndex){

			function processResponse(response) {
				var queryContent = response.data;
				console.log("fillFavoriteChannels response OK index:"+userProfileIndex);
				console.log("fillFavoriteChannels response length:"+response.data.length);

				// when answer is received, a new entry "content" 
				// is created and filled in vm.userprofiles model
				vm.userprofiles[userProfileIndex].favoriteChannels=[];
				vm.userprofiles[userProfileIndex].favoriteChannels.push(queryContent);
				vm.rawData = response.data;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}

			console.log("Send query fillFavoriteChannels to sanbox:"+vm.userprofiles[userProfileIndex].id);
			userprofiles.fillFavoriteChannels(vm.userprofiles[userProfileIndex]).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

		};

		
		
		
		vm.updateProfile = function(userprof){


			function processResponse(response) {
				var queryContent = response;
				console.log("updateProfile response OK index:"+userprof.num);

				// when answer is received, a new entry "content" 
				// is created and filled in vm.userprofiles model
				vm.busy = false;
				vm.updateFlag=false;

			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
			var content = userprof.content[0];
			console.log("Send query updateProfile to sanbox:"+content.uiLanguage);
			console.log("selectedUiLanguage:"+vm.selectedUiLanguage);
			console.log("userProfileIndex ID:"+userprof.num);


			if(vm.selectedDisplayName!== '' && content.displayName !== vm.selectedDisplayName) {
				vm.updateFlag=true;
				content.displayName = vm.selectedDisplayName;
			}

			if(vm.selectedUiLanguage!== '' && content.uiLanguage !== vm.selectedUiLanguage.name) {
				vm.updateFlag=true;
				content.uiLanguage = vm.selectedUiLanguage.name;
			}

			if(vm.selectedAudioLanguage!== '' && content.audioLanguage !== vm.selectedAudioLanguage.name) {
				vm.updateFlag=true;
				content.audioLanguage = vm.selectedAudioLanguage.name;
			}

			if(vm.selectedSubtitlesLanguage!== '' && content.subtitlesLanguage !== vm.selectedSubtitlesLanguage.name) {
				vm.updateFlag=true;
				content.subtitlesLanguage = vm.selectedSubtitlesLanguage.name;
			}

			if(vm.selectedPresentSubtitles!== '' && content.presentSubtitles !== vm.selectedPresentSubtitles.name) {
				vm.updateFlag=true;
				content.presentSubtitles = vm.selectedPresentSubtitles.name;
			}

			if(vm.selectedPresentClosedCaptions!== '' && content.presentClosedCaptions !== vm.selectedPresentClosedCaptions.name) {
				vm.updateFlag=true;
				content.presentClosedCaptions = vm.selectedPresentClosedCaptions.name;
			}

			if(vm.selectedClosedCaptionsTrack!== '' && content.closedCaptionsTrack !== vm.selectedClosedCaptionsTrack.name) {
				vm.updateFlag=true;
				content.closedCaptionsTrack = vm.selectedClosedCaptionsTrack.name;
			}

			if(vm.selectedParentalRatingThreshold!== '' && content.parentalRatingThreshold !== vm.selectedParentalRatingThreshold.name) {
				vm.updateFlag=true;
				content.parentalRatingThreshold = vm.selectedParentalRatingThreshold.name;
			}


			if(vm.updateFlag===true) {
				userprofiles.updateProfile(vm.userprofiles[userprof.num]).then(
						function(response){		
							processResponse(response);
						}, function(error){
							processError(error);
						}

				);
			}

		};

		vm.removeFavorite = function(userprof,channelRef){


			function processResponse(response) {
				var queryContent = response;
				console.log("removeFavorite response OK index:"+userprof.num);
				console.log("removeFavorite channelRef:"+channelRef);
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
			var content = userprof.content[0];
			console.log("Send query removeFavorite to sanbox:"+content.uiLanguage);
			console.log("userProfile index:"+userprof.num);

			userprofiles.removeFavorite(vm.userprofiles[userprof.num],channelRef).then(
						function(response){		
							processResponse(response);
						}, function(error){
							processError(error);
						}

				);

		};

		settings.subscribe($scope, "userprofiles", function() {
			vm.getUserProfiles(true);
		});

	};


})());