((function(){

	angular
	.module('InfiniteEPG')
	.controller('hypermetadataCtrl', hypermetadataCtrl);


//	hypermetadataCtrl.$inject = ['$window', '$location', '$scope', '$routeParams', 'hypermetadata', 'agg', 'settings', 'pins'];
//	function hypermetadataCtrl($window, $location, $scope, $routeParams, hypermetadata, agg, settings, pins) {


	hypermetadataCtrl.$inject = ['$window','$routeParams', '$location','hypermetadata'];
	function hypermetadataCtrl($window, $routeParams, $location, hypermetadata) {
		var vm = this;
		vm.query = null;
		vm.hypermetadata = [];
		vm.movieorgmetadata = [];


		vm.getPersonalMetaData = function(actor){

			console.log("getPersonalMetaData actor.name ==> "+actor.name);
			if(actor.name !== undefined) {
				$window.localStorage["actor"] = JSON.stringify(actor);
				$location.path("/personalmetadata/cast="+actor.name);    		    		
			}
		}


		// Function used to get info from MovieOrg for hypermetadata
		vm.findBioMovieOrg = function(pos,id){

			var position=pos;
			vm.busy = true;

			console.log("Send query findBioMovieOrg to MovieOrg ID:"+id);
			hypermetadata.findBioMovieOrg(id).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				var queryContent = response.data;
				console.log("MovieOrg response OK. FIND PERSON="+queryContent.name);
				console.log("born in "+queryContent.place_of_birth);
				vm.busy = false;

				if(queryContent.name) {
					vm.movieorgmetadata[0].cast[0].cast[position].biography=[];
					vm.movieorgmetadata[0].cast[0].cast[position].biography.push(queryContent);
					//vm.rawData2 = response.data;

					console.log("ADD PERSON ==>"+queryContent.name);
					// console.log("ADD PERSON ==>"+JSON.stringify(queryContent));
				}
			}



			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};






		// Function used to get info from MovieOrg for hypermetadata
		vm.findImdbCastMovieOrg = function(id){

			vm.busy = true;

			console.log("Send query findCastMovieOrg to MovieOrg:");
			hypermetadata.findImdbCastMovieOrg(id).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				var queryContent = response.data;
				console.log("MovieOrg response OK. FIND CAST="+queryContent.cast[0].character);
				vm.busy = false;

				if(queryContent.cast[0].character) {
					vm.movieorgmetadata[0].cast=[];
					vm.movieorgmetadata[0].cast.push(queryContent);
					vm.rawData = response.data;
					console.log("ADD CAST ==>"+JSON.stringify(queryContent));
				}

				for (var i=0;i<queryContent.cast.length;i++){
					vm.findBioMovieOrg(i,queryContent.cast[i].id);
				}


			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};




		// Function used to get info from MovieOrg for one actor
		vm.findPersonalRecord = function(actor) {
			vm.rawData3 = null;
			vm.person = [];
			vm.actor = actor;
			vm.busy = true;

			console.log("Send query findPersonalRecord to MovieOrg:");
			hypermetadata.findPersonalRecord(actor).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				var queryContent = response.data;
				vm.busy = false;
				console.log("ADD PersonalRecord ==>");
				// console.log("ADD PersonalRecord ==>"+JSON.stringify(queryContent));

				if(queryContent.results) {
					console.log("MovieOrg response OK. FIND findPersonalRecord="+queryContent.results[0].original_title);
					console.log("released "+queryContent.results[0].release_date);
					vm.person.push(queryContent.results);
					vm.rawData3 = response.data;
				}

			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};




		// Function used to get info from MovieOrg for hypermetadata
		vm.findImdbMovieOrg = function(id){

			vm.busy = true;

			console.log("Send query findImdbMovieOrg to MovieOrg:");
			hypermetadata.findImdbMovieOrg(id).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				console.log("MovieOrg response OK. FIND MOVIE="+response.data.success);
				vm.busy = false;
				var queryContent = response.data;
				if(queryContent.movie_results.length>0) {
					vm.movieorgmetadata.push(queryContent.movie_results[0]);
					console.log("ADD MOVIE ==>"+JSON.stringify(queryContent.movie_results));
				}

				if(queryContent.person_results.length>0) {
					vm.movieorgmetadata.push(queryContent.person_results);
					console.log("ADD PERSON ==>"+queryContent.person_results.name);
					// console.log("ADD PERSON ==>"+JSON.stringify(queryContent.person_results));
				}
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};

		// Function used to get info from MovieOrg for hypermetadata
		vm.findMovieOrg = function(id){

			vm.busy = true;
			console.log("Send query findMovieOrg to MovieOrg:");
			hypermetadata.findMovieOrg(id).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				console.log("MovieOrg response OK. FIND MOVIE="+response.data.success);
				vm.busy = false;
				var queryContent = response.data;
				if(queryContent) {
					console.log("findImdbMovieOrg MOVIE ==>"+queryContent.imdb_id);
					vm.findImdbMovieOrg(queryContent.imdb_id)
					vm.findImdbCastMovieOrg(queryContent.imdb_id)
				}
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};



		// Function used to get info from MovieOrg for hypermetadata
		vm.searchMovieOrg = function(keyword){

			vm.busy = true;

			console.log("Send query searchMovieOrg to MovieOrg:");
			hypermetadata.searchMovieOrg(keyword).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				console.log("MovieOrg response OK. SEARCH MOVIE="+response.data.success);
				vm.busy = false;
				var queryContent = response.data;
				if(queryContent.results && queryContent.results.length>0) {
					console.log("SEARCH MOVIE ID="+queryContent.results[0].id);
					vm.findMovieOrg(queryContent.results[0].id)
				}

			}



			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};



		// Function used to get info from MovieOrg for hypermetadata
		vm.getSessionMovieOrg = function(token){

			vm.busy = true;
			keyword = vm.query;
			console.log("Send query getSessionMovieOrg to MovieOrg:");
			hypermetadata.getSessionMovieOrg(token).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				console.log("MovieOrg response OK. CREATE SESSION="+response.data.success);
				vm.busy = false;
				console.log("==> DBG vm.hypermetadata="+vm.hypermetadata);
				vm.searchMovieOrg(keyword);
			}
			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};




		// Function used to get info from MovieOrg for hypermetadata
		vm.validateTokenMovieOrg = function(token){

			vm.busy = true;
			console.log("Send query validateTokenMovieOrg to MovieOrg:");
			hypermetadata.validateTokenMovieOrg(token).then(
					function(response){		
						processResponseValidateToken(response);
					}, function(error){
						processErrorValidateToken(error);
					}
			);

			function processResponseValidateToken(response) {
				console.log("MovieOrg response OK. VALIDATE TOKEN="+response.data.success);
				vm.busy = false;
				vm.getSessionMovieOrg(token);

			}
			function processErrorValidateToken(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};



		// Function used to get info from MovieOrg for hypermetadata
		vm.getHyperMetadataMovieOrg = function(reset){

			if (reset){
				vm.hypermetadata = [];
				vm.total = 0;
			}

			
			vm.rawData = null;
			vm.error = null;
			vm.busy = true;			
			
			console.log("Send query getHyperMetadataMovieOrg to MovieOrg for key:"+vm.query);
			hypermetadata.getHyperMetadataMovieOrg().then(
					function(response){		
						processResponseMovieOrg(response);
					}, function(error){
						processErrorMovieOrg(error);
					}
			);

			function processResponseMovieOrg(response) {
				//var queryContent = response.data;
				console.log("MovieOrg response OK.TOKEN="+response.data.request_token);
				token=response.data.request_token;
				vm.busy = false;
				vm.validateTokenMovieOrg(token);
			}
			function processErrorMovieOrg(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};



		var query = $routeParams.query;
		if (query){
			vm.query=query;
			vm.getHyperMetadataMovieOrg(false);
		} 

	};



})());