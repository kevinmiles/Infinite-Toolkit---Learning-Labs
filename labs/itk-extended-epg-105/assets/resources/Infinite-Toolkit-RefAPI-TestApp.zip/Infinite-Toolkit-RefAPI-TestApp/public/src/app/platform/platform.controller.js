((function(){

	angular.module('InfiniteEPG').controller('platformCtrl', platformCtrl);
	platformCtrl.$inject = ['$scope', '$routeParams', 'platform', 'settings', '$http', '$location'];


	function platformCtrl($scope, $routeParams, platform, settings, $http, $location) {
		var vm = this;

		vm.query = {
				limit: 10
		};
		vm.Platform = [];
		var currentOffset = 0;


		vm.getPlatform = function(reset){
			if (reset){
				vm.Platform = [];
				currentOffset = 0;
				vm.total = 0;
			}else {
				if (vm.Platform.length >= vm.total){return;}
			}

			vm.rawData = null;
			vm.error = null;
			vm.busy = true;
			vm.query.offset = currentOffset;
			vm.query.limit = vm.total?Math.min(vm.query.limit, vm.total - currentOffset):vm.query.limit;


			function processResponse(response) {
				var queryContent = response.data.Platform;

				vm.count = response.data.count;
				vm.total = response.data.total;

				for (var i = 0; i < queryContent.length; i++) {
					vm.Platform.push(queryContent[i]);
				}
				vm.rawData = response.data;
				currentOffset = vm.Platform.length;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}


			if(!vm.useDummyJson) {
				console.log("Send query to sanbox:"+vm.query)
				platform.getPlatform(vm.query).then(
						function(response){
							processResponse(response);
						}, function(error){
							processError(error);
						}
				);

			} else {
				console.log("Use dummy Json:");
				$http.get('src/app/platform/aggPlatformSample.json').then(
						function(response){
							processResponse(response);
						}, function(error){
							processError(error);
						}
				);

			}
		};

		settings.subscribe($scope, "platform", function() {
			vm.getPlatform(true);
		});

	};

})());