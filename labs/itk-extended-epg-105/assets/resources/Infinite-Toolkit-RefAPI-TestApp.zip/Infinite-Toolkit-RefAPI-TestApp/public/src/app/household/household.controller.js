((function(){

	angular
	.module('InfiniteEPG')
	.controller('householdCtrl', householdCtrl);

	householdCtrl.$inject = ['household'];
	function householdCtrl(household) {
		var vm = this;

		vm.getHouseholdId = function(reset){
			if (reset){
				vm.household = [];
				vm.total = 0;
			}
			vm.rawData = null;
			vm.error = null;
			vm.busy = true;

			console.log("Send query householdId to sanbox:")
			household.getHousehold(vm.query).then(
					function(response){
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			function processResponse(response) {
				var queryContent = response.data;
				console.log("householdId response OK queryContent="+queryContent.id);
				vm.household.push(queryContent);
				vm.getHouseholdDevices();


				vm.rawData = response.data;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}


		};

		// Function used to get device s registered in this household
		// calling "/household/me/devices" API
		vm.getHouseholdDevices = function(){

			function processResponse(response) {
				var queryContent = response.data;
				console.log("getHouseholdDevices response OK. Number of devices found:"+queryContent.devices.length);
				// when answer is received, a new entry "devices" 
				// is created and filled in vm.household model
				vm.household.content = [];
				vm.household.content.push(queryContent);
				vm.rawData = response.data;
				vm.busy = false;
			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}

			console.log("Send query getHouseholdDevices to sanbox:");
			household.getHouseholdDevices().then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

		};

	};

})());