(function(){

	angular
	.module('InfiniteEPG')
	.service('userprofiles', userprofiles);

	userprofiles.$inject = ["$http", "authentication", "settings"];   
	function userprofiles ($http, authentication, settings) {

		var getUserProfiles = function(query){
			if(settings.getCurrentSandbox().proxy == false){
				return $http.get(settings.getCurrentSandbox().url + "userProfiles",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					},
					params: query
				});
			} else {
				return authentication.getUserprofiles(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers);
			}
		};

		var fillUserProfile = function(query){
			console.log("fillUserProfiles ID: "+query.id);
			if(settings.getCurrentSandbox().proxy == false){
				return $http.get(settings.getCurrentSandbox().url + "userProfiles/"+query.id+"/settings",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					}
				});
			} else {
				return authentication.fillUserprofile(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, query.id);
			}
		};

		var fillFavoriteChannels = function(query){
			console.log("fillFavoriteChanels ID: "+query.id);
			if(settings.getCurrentSandbox().proxy == false){
				return $http.get(settings.getCurrentSandbox().url + "userProfiles/"+query.id+"/settings/favoriteChannels",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					}
				});
			} else {
				return authentication.fillFavoriteChannels(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, query.id);
			}
		};



		var updateProfile = function(queryParams){

			var updateProfileRequest=	settings.getCurrentSandbox().url+ "userProfiles/"+queryParams.id+"/settings";
			var bodyValue= queryParams.content[0];
			console.log("updateProfile number: "+queryParams.num);

			if(!settings.getCurrentSandbox().proxy){
				return $http.post(updateProfileRequest,  bodyValue,
						{
					headers: settings.getSandboxHeaders()					}
				);		
			} else {
				return authentication.updateProfile(updateProfileRequest, settings.getCurrentSandbox().headers);
			}

		};

		var removeFavorite = function(queryParams,channelRef){

			var updateProfileRequest=	settings.getCurrentSandbox().url+ "userProfiles/"+queryParams.id+"/settings/favoriteChannels/"+channelRef;
			console.log("removeFavorite profile number: "+queryParams.num+" id="+queryParams.id);
			console.log("removeFavorite channelRef: "+channelRef);

			if(!settings.getCurrentSandbox().proxy){
				return $http.delete(updateProfileRequest, "",
						{
					headers: settings.getSandboxHeaders()					}
				);		
			} else {
				return authentication.removeFavorite(updateProfileRequest, settings.getCurrentSandbox().headers);
			}

		};


		return {
			getUserProfiles : getUserProfiles,
			fillUserProfile : fillUserProfile,
			fillFavoriteChannels : fillFavoriteChannels,
			updateProfile : updateProfile,
			removeFavorite : removeFavorite,

		};
	}
})();


