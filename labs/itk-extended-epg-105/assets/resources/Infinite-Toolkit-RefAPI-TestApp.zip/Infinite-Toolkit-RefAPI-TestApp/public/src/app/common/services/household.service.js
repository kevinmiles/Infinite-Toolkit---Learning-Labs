(function(){

	angular
	.module('InfiniteEPG')
	.service('household', household);

	household.$inject = ["$http", "authentication", "settings"];   

	function household ($http, authentication, settings) {

		var getHousehold = function(){
			if(settings.getCurrentSandbox().proxy == false){
				return $http.get(settings.getCurrentSandbox().url + "household/me",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					}
				});
			} else {
				return authentication.getHousehold(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers);
			}
		};

		var getHouseholdDevices = function(query){
			console.log("getHouseholdDevices");
			if(settings.getCurrentSandbox().proxy == false){
				return $http.get(settings.getCurrentSandbox().url + "household/me/devices",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					}
				});
			} else {
				return authentication.getHouseholdDevices(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers);
			}
		};


		return {
			getHousehold : getHousehold,
			getHouseholdDevices : getHouseholdDevices,
		};
	}
})();
