((function(){

	angular.module('InfiniteEPG').controller('categoriesListCtrl', categoriesListCtrl);
	categoriesListCtrl.$inject = ['$scope', 'categories', 'settings']
	function categoriesListCtrl($scope, categories, settings) {
		var vm = this;

		vm.query = {};

		vm.listCategories = function(query){
			vm.categories = null;
			vm.rawData = null;
			vm.error = null;
			categories.listCategories(query)
			.then(function(response){
				vm.categories = response.data.categories;
				vm.rawData = response.data;
				// Search for non leaf node and fill tree structure
				for(var n=0;n<response.data.categories.length;n++) {
					if(response.data.categories[n].leaf === false) {
						vm.fillSubCategories(n);
					}
				}
			}, function(error){
				vm.error = error.data;
			});

		};

		vm.fillSubCategories = function(n){
			vm.categories[n].categories={};
			vm.error = null;

			categories.fillSubCategories(vm.categories[n].id)
			.then(function(response){
				var count = response.data.categories.length;
				//  fill tree structure with new categories
				for(var n=0;n<count;n++) {
					var data = response.data.categories[n];
					vm.categories.push(data);
					// recursively fill tree structure if non leaf node
					if(data.leaf === false) {
						categories.fillSubCategories(n);
					}
				}
			}, function(error){
				vm.error = error.data;
			});

		};

		vm.listCategories(null);

		settings.subscribe($scope, "cats", function() {
			vm.listCategories(vm.query);
		});

	};

})());