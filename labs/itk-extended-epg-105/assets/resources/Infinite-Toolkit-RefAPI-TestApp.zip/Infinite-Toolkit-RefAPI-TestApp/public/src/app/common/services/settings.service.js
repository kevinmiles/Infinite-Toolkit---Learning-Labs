(function(){

	angular
	.module('InfiniteEPG')
	.service('settings', settings);

	settings.$inject = ["$window", "$http", "$rootScope", "$location","authentication"];   
	function settings ($window, $http, $rootScope, $location, authentication) {

		var localSB = null;

		var _saveSettings = function() {
			$window.localStorage["InfiniteEPG-settings"] = JSON.stringify(_currentSandbox);
		};

		var _saveLocalSandboxes = function() {
			$window.localStorage["InfiniteEPG-sandboxes"] = JSON.stringify(_localSandboxes);
		};

		var resetLocalSandboxes = function(){
			$window.localStorage["InfiniteEPG-sandboxes"] ="";
		}

		var getUrlOmdb = function(){
			return 'http://www.omdbapi.com/';
		}

		var getUrlMovieOrg = function(){
			return 'https://api.themoviedb.org/3/'
		}
		
		
		var getApiKeyMovieOrg = function(){
			return 'api_key=bc3d4835279dff878d0eb29099a26b78';
		}
		

		var getGetTokenMovieOrg = function(){
			return getUrlMovieOrg()+'authentication/token/new?'+getApiKeyMovieOrg();
		}
		
		var validateTokenMovieOrg = function(){
			return getUrlMovieOrg()+'authentication/token/validate_with_login?'+getApiKeyMovieOrg()+'&username=serie64&password=Bolivar_64&request_token=';
			
		}

		var getSessionMovieOrg = function(){
			return getUrlMovieOrg()+'authentication/session/new?'+getApiKeyMovieOrg()+'&request_token=';			
		}

		var getSandboxes = function(){
			return $http.get("api/sandboxes").then(function(response){
				if (!getCurrentSandbox()){
					//console.log("==> NO CURRENT SANDBOX SET FIRST OF THE LIST"+response.data[0].url);
					setCurrentSandbox(response.data[0]);
				}
				localSB = getLocalSandboxes();
				if(localSB !== undefined && localSB.length >0) {
					if(localSB.length > response.data.length) {
						for(var i=response.data.length;i<localSB.length;i++)
							response.data.push(localSB[i]);
					}
				}
				return response;
			});
		};

		var _currentSandbox;
		var _localSandboxes;

		var getCurrentSandbox = function(){
			var t = $window.localStorage["InfiniteEPG-settings"];
			if (t){
				return JSON.parse(t);
			}
		};


		var getLocalSandboxes = function(){
			var t = $window.localStorage["InfiniteEPG-sandboxes"];
			if (t){
				return JSON.parse(t);
			}
		};


		var deleteOneLocalSandboxe = function(name){
			found=-1;
			if(localSB !== undefined && localSB.length>0)
			{
				for(var i=0;i<localSB.length;i++)
				{
					if(localSB[i].name === name) 
						found=i; 
				}
			}

			if(found>=0) {
				console.log("==> FOUND SANDBOX TO DELETE "+found);
				localSB.splice(found,1);
				_localSandboxes=localSB;
				_saveLocalSandboxes();
				notify();
			}
		};


		var getSandboxURL = function(){

		};

		var getSandboxHeaders = function(){
			var sandbox = getCurrentSandbox();
			if (sandbox.headers){
				return sandbox.headers;
			}else{
				return {
					Authorization: "Bearer "+authentication.getAccessToken()
				}
			}
		};

		var getProxy = function(){		
			return "";
		}

		var setLocalSandboxes = function(sandboxes){
			// console.log("==> JSON:"+JSON.stringify(sandboxes));
			_localSandboxes = sandboxes;
			_saveLocalSandboxes();
			notify();
		};

		var setCurrentSandbox = function(sandbox){

			if(sandbox.url[sandbox.url.length-1] === '/') {
				console.log("==> setCurrentSandbox URL OK:"+sandbox.url);
				
			} else {
				console.log("==> setCurrentSandbox URL KO need ending /:"+sandbox.url);
				sandbox.url+='/';
			}
			

			// A special item has been added to the head-end list in order to have a quick link access
			// to Create / Modify / Delete a existing local head-end.
			// see init in navigation.controller
			if(sandbox.url[0]==='/') {
				$location.path(sandbox.url);
			} else {

				if (sandbox.proxy){sandbox.url = getProxy()+sandbox.url}
				_currentSandbox = sandbox;
				_saveSettings();
				notify();
			}

		};

		var notify = function(){
			$rootScope.$emit('settings-service-event');
		};

		var cbs = [], ids = [];
		var cbf = function(){
			cbs.forEach(function(cb){
				cb();
			});
		};


		return {
			subscribe: function(scope, id, callback) {
				if (ids.indexOf(id) >= 0){
					cbs[ids.indexOf(id)] = callback;
					return;
				} else {
					ids.push(id);
					cbs.push(callback);    
				}
				var handler = $rootScope.$on('settings-service-event', cbf);
				scope.$on('$destroy', handler);
			},
			getSandboxes : getSandboxes,
			resetLocalSandboxes: resetLocalSandboxes,
			deleteOneLocalSandboxe: deleteOneLocalSandboxe,
			setCurrentSandbox : setCurrentSandbox,
			setLocalSandboxes: setLocalSandboxes,
			getCurrentSandbox : getCurrentSandbox,
			getSandboxHeaders : getSandboxHeaders,
			getProxy : getProxy,
			getUrlOmdb : getUrlOmdb,
			getGetTokenMovieOrg : getGetTokenMovieOrg,
			validateTokenMovieOrg : validateTokenMovieOrg,
			getSessionMovieOrg : getSessionMovieOrg,
			getUrlMovieOrg : getUrlMovieOrg,
			getApiKeyMovieOrg : getApiKeyMovieOrg,
		};
	}
})();
