(function(){

  angular
  .module('InfiniteEPG')
  .service('channels', channels);

  channels.$inject = ["$http", "authentication", "settings"];   
  function channels ($http, authentication, settings) {

          var listChannels = function(query){
              if(settings.getCurrentSandbox().proxy == false){
                  return $http.get(settings.getCurrentSandbox().url + "channels",  {
                      headers: {
                          Authorization: "Bearer "+authentication.getAccessToken()
                      },
                      params: query
                  });
              } else {
                  return authentication.channels(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, query);
              }
          };
      
      return {
          listChannels : listChannels,
      };
 }
})();
