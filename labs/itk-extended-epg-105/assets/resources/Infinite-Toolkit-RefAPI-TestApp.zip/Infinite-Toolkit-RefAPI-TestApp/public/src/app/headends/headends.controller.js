((function(){

	angular.module('InfiniteEPG').controller('headendsCtrl', headendsCtrl);
	headendsCtrl.$inject = ['$scope', '$routeParams', 'settings'];

	function headendsCtrl($scope, $routeParams, settings ) {
		var vm = this;
		vm.rawData = null;
		vm.query = null;
		vm.busy = false;

		var _getSandboxes = function(){
			settings.getSandboxes()
			.then(function(response){
				vm.directAccess = false;
				vm.sandboxes = response.data;
				vm.rawData = response.data;

				if( vm.directAccess ) {
					// Remove proxy false elements of the list
					for(var i = vm.sandboxes.length - 1; i >= 0; i--) {
						if(vm.sandboxes[i].proxy != true) {
							vm.sandboxes.splice(i, 1);
						}
					}
				}


				if ( !vm.busy && vm.query !== null && vm.query.name !== undefined && vm.query.url !== undefined && vm.query.proxy !== undefined)
				{

					console.log("==> SUBMIT : "+vm.query.name);

					// Sometimes tools like PostMan uses different double quote symbol.
					var ciscoID = vm.query.ciscoIdentity.replace('\”','\"');
					// Path separator must be / . Replace all \ by /.
					var Url = vm.query.url.replace(/\\/g,'/');
					if ( !Url.endsWith("/") ) {
						Url+='/';
					}

					var headers = { 'Cache-Control': vm.query.cachecontrol, 'x-cisco-vcs-identity':ciscoID};
					var newHE = { 'name': vm.query.name, 'url': Url, 'proxy': vm.query.proxy, 'headers': headers, 'local':true};

					// 
					var found=-1;
					for(var i = 0; i < vm.sandboxes.length ; i++) {
						if(vm.sandboxes[i].name === vm.query.name) {
							console.log("Modify existing sandboxes : "+vm.query.name);
							vm.sandboxes[i].url=Url;
							vm.sandboxes[i].headers=headers;							
							found=i;
							vm.query=null;

						}
					}

					if(found<0) {
						vm.query=null
						vm.sandboxes.push(newHE);
					}

					settings.setLocalSandboxes(vm.sandboxes);
				}

			}, function(error){
				console.error(error);
			})
		};



		vm.getHeadEnds = function(reset){
			vm.error = null;
			_getSandboxes();

		};

		vm.resetLocalHeadEnds = function(){
			console.log("reset sanboxes list:");
			settings.resetLocalSandboxes();
		};


		vm.resetOneLocalHeadEnd = function(name){
			console.log("delete sanboxes:"+name);
			settings.deleteOneLocalSandboxe(name);
		};





		vm.editLocalHeadEnd = function(name){
			console.log("edit sanboxe :"+name);

			for(var i = 0; i < vm.sandboxes.length ; i++) {
				if(vm.sandboxes[i].name === name) {

					var head = vm.sandboxes[i].headers;
					var ciscoId = null;
					var cacheControl = null;

					for (var k in head){
						if (typeof head[k] !== 'function') {
							if(k==='Cache-Control') cacheControl=head[k];
							if(k==='x-cisco-vcs-identity') ciscoId=head[k];
						}
					}

					vm.query=
					{
							'name' : vm.sandboxes[i].name,
							'proxy' : vm.sandboxes[i].proxy,
							'ciscoIdentity' : ciscoId,
							'cachecontrol' : cacheControl
					}


				}
			}

			// $('#collapse1').collapse('show');

		};


		settings.subscribe($scope, "headends", function() {
			vm.getHeadEnds(true);
		});

	};


})());