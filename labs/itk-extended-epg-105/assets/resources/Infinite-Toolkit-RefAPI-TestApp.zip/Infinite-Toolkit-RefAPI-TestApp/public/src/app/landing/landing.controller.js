((function(){

angular.module('InfiniteEPG').controller('landingCtrl', landingCtrl);
  landingCtrl.$inject = ['$scope', '$location', 'channels', 'authentication'];
  function landingCtrl($scope, $location, channels, authentication) {
   var vm = this;
  
  vm.isLoggedIn = authentication.isLoggedIn();
  vm.directAccess = authentication.isDirectAccess();
  $scope.checkbox_directAccess = vm.directAccess;
  processedPage = $location.search().page || "/";
  vm.returnPage = "login?page="+processedPage;
  vm.showHide = vm.isLoggedIn || vm.directAccess;
  
  console.log(" Start vm.directAccess   : "+ vm.directAccess);
  console.log(" Start vm.isLoggedIn     : "+ vm.isLoggedIn);
  console.log(" Start vm.showHide       : "+ vm.showHide);
  console.log(" Start vm.returnPage     : "+ vm.returnPage);

  vm.change = function() {
    console.log(" Callback authentication.isDirectAccess() : "+ authentication.isDirectAccess());
           
    if($scope.checkbox_directAccess){
        console.log("test1");
        authentication.logout();
        vm.returnPage = "/toto ";
        authentication.saveDirectaccess({ "directaccess" : true});
        //$location.path("/#/");
        //$location.replace();
        //$window.location.reload();
    } else
    {
        console.log("test2");
        processedPage = $location.search().page || "/";
        vm.returnPage = "login?page="+processedPage;
        authentication.saveDirectaccess({ "directaccess" : false});
        //vm.returnPage = "/#/login?page=%2F";
        //$location.path("/#/login?page=%2F");
        //$location.replace();
        //$window.location.reload();
    }
    console.log(" vm.returnPage             : "+ vm.returnPage);
    //$location.path(vm.returnPage);
    //$window.location.reload();
  };

    authentication.subscribe($scope, "landing", function() {
      vm.isLoggedIn = authentication.isLoggedIn();
    });
  
    vm.login = function(){
    authentication.login();
  }
 
};

})());
