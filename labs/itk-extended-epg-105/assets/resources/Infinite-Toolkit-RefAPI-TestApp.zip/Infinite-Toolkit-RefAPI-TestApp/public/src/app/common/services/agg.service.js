(function(){

	angular
	.module('InfiniteEPG')
	.service('agg', agg);

	agg.$inject = ["$http", "authentication", "settings"];   
	function agg ($http, authentication, settings) {
		var getGrid = function(query){
			if(!settings.getCurrentSandbox().proxy){
				return $http.get(settings.getCurrentSandbox().url + "agg/grid",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					},
					params: query
				});
			} else {
				console.log("==> grid param.limit:"+query.limit);

				return authentication.grid(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, query );
			}
		};

		var getContent = function(query){
			if(!settings.getCurrentSandbox().proxy){
				return $http.get(settings.getCurrentSandbox().url + "agg/content",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					},
					params: query
				});
			} else {
				return authentication.content(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, query );
			}
		};   



		var deleteBooking = function(booking){

			if(!settings.getCurrentSandbox().proxy){
				return $http.delete(settings.getCurrentSandbox().url + "agg/library/bookings/"+booking.id,  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					}
				});
			} else {
				return authentication.deleteBooking(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers,booking.id);
			}
		};  

		var fillBookingsFromPlanner = function(query){
			if(!settings.getCurrentSandbox().proxy){
				return $http.get(settings.getCurrentSandbox().url + "agg/library/planner",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					},
					params: query
				});
			} else {
				return authentication.fillBookingsFromPlanner(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers, query );
			}
		};  

		var fillBookingsFromPlanner = function(query){
			if(!settings.getCurrentSandbox().proxy){
				return $http.get(settings.getCurrentSandbox().url + "agg/library/planner",  {
					headers: {
						Authorization: "Bearer "+authentication.getAccessToken()
					},
					params: query
				});
			} else {
				return authentication.fillBookingsFromPlanner(settings.getCurrentSandbox().url, settings.getCurrentSandbox().headers );
			}
		};  





		var bookRecordFromGrid =  function(content){
			if(!settings.getCurrentSandbox().proxy){
				var req = {
						method: 'POST',
						url: settings.getCurrentSandbox().url + "agg/library/bookings",
						headers: {
							Authorization: "Bearer "+authentication.getAccessToken(),
							'Content-Type': "application/json"
						},
						data: { contentInstanceId: content.id,
							bookingType: content.type,
							conflictDetectOption: 'none',
							targetDevices: ['cDVR'] }
				} ;         

				return $http(req).then(function(response){return response.body});
			} else {
				return authentication.bookRecordfromGrid(settings.getCurrentSandbox().url+"agg/library/bookings", settings.getCurrentSandbox().headers, content);
			}
		};
		return {
			getGrid : getGrid,
			getContent : getContent,
			fillBookingsFromPlanner : fillBookingsFromPlanner,
			deleteBooking : deleteBooking,
			bookRecordfromGrid : bookRecordFromGrid,
		};
	}
})();
