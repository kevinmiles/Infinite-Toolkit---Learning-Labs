((function(){

	angular
	.module('InfiniteEPG')
	.controller('personalmetadataCtrl', personalmetadataCtrl);


	personalmetadataCtrl.$inject = ['$window', '$routeParams', 'hypermetadata'];

	function personalmetadataCtrl($window, $routeParams, hypermetadata) {

		var vm = this;

		vm.query = null;
		vm.actor = null;
		vm.movie = [];
		
		
		vm.initModel = function(reset){
			console.log("vm.initModel:"+reset);
			
			var t = $window.localStorage["actor"];
			if (t){
				vm.actor = JSON.parse(t);
			}
			

			console.log("vm.actor.id:"+vm.actor.id);
			console.log(" ADD PERSON ==>"+JSON.stringify(vm.actor));

			if (reset){
				vm.movie = [];
			}

			//vm.rawData = null;
			vm.error = null;

			vm.findPersonalRecord(vm.actor);
			
		};






		// Function used to get info from MovieOrg for one actor
		vm.findPersonalRecord = function(actor) {
			vm.rawData3 = null;
			//vm.movie = [];
			//vm.actor = actor;
			vm.busy = true;

			console.log("Send query findPersonalRecord to sanbox:");
			hypermetadata.findPersonalRecord(actor).then(
					function(response){		
						processResponse(response);
					}, function(error){
						processError(error);
					}
			);

			
			function processResponse(response) {
				var queryContent = response.data;
				vm.busy = false;
				var i=0;
				

				if(queryContent.results) {					
					for(i=0;i<queryContent.results.length;i++) {
					vm.movie.push(queryContent.results[i]);
					console.log("ADD RESULT  ==>"+JSON.stringify(queryContent.results[i]));
				}
				
					vm.rawData3 = response.data;

				}

			}

			function processError(error) {
				vm.busy = false;
				vm.error = error.data;
			}
		};





		var query = $routeParams.query;
		if (query){
			vm.query=query;
			console.log("PERSONAL METADATA QUERY ==>"+JSON.stringify(vm.query));
		} 

		vm.initModel(true);

	};



})());