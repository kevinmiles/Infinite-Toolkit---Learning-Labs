(function(){

	angular
	.module('InfiniteEPG')
	.service('hypermetadata', hypermetadata);

	hypermetadata.$inject = ["$http", "authentication", "settings"];   

	function hypermetadata ($http, authentication, settings) {

		
		var findImdbMovieOrg = function(id){
			console.log("QUERY findImdbMovieOrg ID to find:"+id);
				return $http.get(settings.getUrlMovieOrg() + "find/"+id+"?external_source=imdb_id&"+settings.getApiKeyMovieOrg(),  {
				});
			
		};
		var findMovieOrg = function(id){
			console.log("QUERY findMovieOrg ID to find:"+id);
			return $http.get(settings.getUrlMovieOrg() + "movie/"+id+"?"+settings.getApiKeyMovieOrg(),  {
			});
		
	};
			
		var searchMovieOrg = function(keyword){
			console.log("QUERY searchMovieOrg key to find:"+keyword);
				return $http.get(settings.getUrlMovieOrg() + "search/movie?query="+keyword+"&"+settings.getApiKeyMovieOrg(),  {
				});
			
		};

		var findImdbCastMovieOrg = function(id){
			console.log("QUERY findCastMovieOrg ID to find:"+id);
				return $http.get(settings.getUrlMovieOrg() + "movie/"+id+"/credits?"+settings.getApiKeyMovieOrg(),  {
				});
			
		};

		var searchCastMovieOrg = function(key){
			console.log("QUERY searchCastMovieOrg ID to find:"+id);
				return $http.get(settings.getUrlMovieOrg() + "search/keyword?query="+key+"&"+settings.getApiKeyMovieOrg(),  {
				});
			
		};

		
		var findBioMovieOrg = function(id){
			console.log("QUERY findBioMovieOrg ID to find:"+id);
				return $http.get(settings.getUrlMovieOrg() + "person/"+id+"?"+settings.getApiKeyMovieOrg(),  {
				});
			
		};

		var findPersonalRecord = function(actor){
			console.log("findPersonalRecord MovieOrg :"+actor.name+" / ID:"+actor.id);
			return $http.get(settings.getUrlMovieOrg() + "discover/movie?"+settings.getApiKeyMovieOrg()+"&with_cast="+actor.id+"&sort_by=popularity.desc",  {
				});


		};
		var getHyperMetadataOmdb = function(query,apikey){
			console.log("QUERY Omdb :"+query);
				return $http.get(settings.getUrlOmdb() + "?apikey="+apikey+"&"+query,  {
				});
			
		};

		
		var validateTokenMovieOrg = function(token){
				console.log("validateTokenMovieOrg token:"+token);
				return $http.get(settings.validateTokenMovieOrg()+token ,  {
				});
			
		};

		var getSessionMovieOrg = function(token){
				console.log("getSessionMovieOrg token:"+token);
				return $http.get(settings.getSessionMovieOrg()+token ,  {
				});
			
		};
		
		var getHyperMetadataMovieOrg = function(){
			console.log("QUERY getGetTokenMovieOrg  :"+settings.getGetTokenMovieOrg());
				return $http.get(settings.getGetTokenMovieOrg(),  {
				});
			
		};
		

		

		  
		return {
			getHyperMetadataOmdb : getHyperMetadataOmdb,
			getHyperMetadataMovieOrg : getHyperMetadataMovieOrg,
			validateTokenMovieOrg : validateTokenMovieOrg,
			getSessionMovieOrg : getSessionMovieOrg,
			searchMovieOrg : searchMovieOrg,
			searchCastMovieOrg : searchCastMovieOrg,
			findMovieOrg : findMovieOrg,

			findImdbMovieOrg : findImdbMovieOrg,
			findImdbCastMovieOrg : findImdbCastMovieOrg,
			findBioMovieOrg : findBioMovieOrg,
			findPersonalRecord : findPersonalRecord,
			
		};
	}
})();
