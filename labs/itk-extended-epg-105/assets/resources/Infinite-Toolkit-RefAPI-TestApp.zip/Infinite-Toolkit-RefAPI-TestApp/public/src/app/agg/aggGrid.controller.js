((function(){

  angular.module('InfiniteEPG').controller('aggGridCtrl', aggGridCtrl);
  aggGridCtrl.$inject = ['$scope', '$routeParams', 'agg', 'settings'];
  function aggGridCtrl($scope, $routeParams, agg, settings) {
    var vm = this;

    vm.query = {
      eventsLimit: 5,
      limit: 10
    };
    vm.grid = [];
    var currentOffset = 0;

    vm.getGrid = function(reset){
      if (reset){
        vm.grid = [];
        currentOffset = 0;
        vm.total = 0;
      }else {
        if (vm.grid.length >= vm.total){return;}
      }
      vm.ok = false;
      vm.rawData = null;
      vm.error = null;
      vm.busy = true;
      vm.query.offset = currentOffset;
      vm.query.limit = vm.total?Math.min(vm.query.limit, vm.total - currentOffset):vm.query.limit;
      agg.getGrid(vm.query)
      .then(function(response){
        var queryContent = response.data.channels;
        vm.count = response.data.count;
        vm.total = response.data.total;
        for (var i = 0; i < queryContent.length; i++) {
          vm.grid.push(queryContent[i]);
        }
        vm.rawData = response.data;
        currentOffset = vm.grid.length;
        vm.busy = false;
      }, function(error){
        vm.busy = false;
        vm.error = error.data;
      });
      
    };

    vm.bookRecord = function(content){
      vm.ok = false;
      agg.bookRecordfromGrid(content)
      .then(function(response){
        vm.ok = true;
        vm.bookRecordNotif = "Event Successfully Booked";
        vm.busy = false;  
      }, function(error){
        vm.busy = false;
        switch (error.status){
           case 401:
              vm.error = "Bad or expired token: ";
              break;
           case 403:
              vm.error = "Resource Already Exist: ";
              break;
           case 409:
              vm.error = "Booking not created due to conflict on following bookings: ";
              break;
            default:
              vm.error ="Unknown error message: ";
              break;
        }

        vm.error += JSON.stringify(error.data,null,2);
      });
    };

    vm.checkIfBookable = function(channelId,bookingType){
      if (channelId === undefined || bookingType === undefined){
          return false;
      } else {
        // TODO remove traces afterwards
        console.log("channelId= "+channelId+ " bookingType= "+bookingType);
    
        // make sure bookingType is of type event as per single booking in mulesoft
        return (bookingType === 'event')?true:false;
      }
    };
    
    settings.subscribe($scope, "grid", function() {
      vm.getGrid(true);
    });
    
  };

})());