# Infinite-Toolkit-RefAPI-TestApp
The aim of this project is to provide a basic tool to browse live channels and VOD assets (displaying images, metadata, use filtering criteria, etc ...) files when doing some requests.
It's also possible to playback video content.

## Installation
The basic Infinite EPG can be locally installed but the following command:
`git clone git@github3.cisco.com:InfiniteToolkit/Infinite-Toolkit-RefAPI-TestApp.git
`


Some other 'extended' feature are also available by performing the following checkout:

- **Voice recognition** using **Alexa** module
`git checkout EXTENDED_VOICERECOG
`
> With this feature, the user is able to send a vocal command in order to switch to a specific Live Channel.
>

</br>

- **Extra Metadata** provided by public APIs : **OMDB** and **TheMovie.org** 
`git checkout EXTENDED_METADATA_FROM_PUBLIC_API
`
> With this feature, the EPG is adding information about the selected movie,
> such as poster, actors list, director, released date, ...
> For each actor, a personnal page can also be displayed with his most popular movies.

## Setup and running

Installation has been done with **npm** version 2.15.8, **node** version v4.4.7.  

In order to install the server just launch:

```{r, engine='bash', count_lines}
npm install 
```

## Usage

Here are the basic commands to make the server work.

To start the process

```{r, engine='bash', count_lines}
npm start
```

Then access it on your favorite browser http://localhost:3000/

To stop the process

```{r, engine='bash', count_lines}
Ctrl + c on your keyboard
```
## Default value

To work correctly, the server express needs to have a .env file at the root. (Same place as package.json)

The file has to be written this way

```{r, engine='bash', count_lines}
NODE_ENV=Production
DEFAULT_CLIENT_ID=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
DEFAULT_CLIENT_SECRET=XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
```

It is MANDATORY to have a cariage return after the last line.

Alternatively, you can describe three environment variables instead of using the .env file.

With NODE_ENV the mode (Production or developpement, only production is working so far), the CLIENT_ID and CLIENT_SECRET of your favorite anypoint application,
that will be used as default login application.

Furthermore a hidden file giving the differents portal is availabe at the same level as .env file. It gives the default portals abailable under the application.
The file is ".portals.json".

```{r, engine='bash', count_lines}
[
{"name": "Production", "url": "https://apx.cisco.com/spvss/infinitehome/infinitetoolkit/v_sandbox_1/", "proxy" : false},
{"name": "Dev", "url": "https://apx.cisco.com/spvss/infinitehome/infinitetoolkit/v_sandbox_1/", "proxy" : false}, 
{"name": "IBC", "url": "https://apx.cisco.com/spvss/infinitehome/infinitetoolkit/v2_ibc_2016/", "proxy" : false}, 
{"name": "ProxyJS", "url": "http://icebox.spvsstmedmz.cisco.com/ctap/r1.3.0/", "proxy" : true,  
    "headers": { "Cache-Control": "no cache",
        "x-cisco-vcs-identity": "{ \"upId\": \"itk_0\", \"hhId\": \"itk\", \"devId\": \"1CABC3FC39D55128\", \"cmdcRegion\": \"16384~16639\", \"deviceFeatures\": [\"COMPANION\", \"ABR\", \"ANDROID\", \"WIFI-CHIP\", \"PHONE\", \"VG-DRM\"], \"cmdcDeviceType\": \"ANDROID\", \"sessionId\": \"b705d50d-82f0-4ad5-afc7-a61b1bf29aeb\", \"tenant\": \"k\", \"region\": \"100\" }"
    }
}
]
```

Headers has sometime to be specified, you can check it under confluence website [Portal references](http://spvss-confluence.cisco.com/display/IT/Portal+references).
