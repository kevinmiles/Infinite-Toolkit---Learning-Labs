var express = require('express');
var router = express.Router();
var fs = require('fs');



/* Expected URL fomrat (example)
	http://localhost:8090//ctap/r1.3.0/contentInstances/DSNY2395427000000171~DSNY2395427000000173
*/
router.get('/*', function(req, res, next) 
{

	// Getting HTTP headers
	console.log("x-forwarded-for header: " + req.headers['x-forwarded-for']);
	console.log("x-cisco-device-state: " + req.headers['x-cisco-device-state']);
	console.log("x-cisco-vcs-identity: " + req.headers['x-cisco-vcs-identity']);

//	var apiServerHost= 
//'https://apx.cisco.com/spvss/infinitehome/ivptoolkit/clientrefapi/sandbox_0.4.1/contentInstances'+req._parsedUrl.search;

	var pos = req._parsedUrl.search.indexOf('categoryId=WATCHLIST_ID');
	

	if(pos>0) {
			var filename =  './data/contentInstances_watchlist.json';
	// Input of response is a json file
	fs.readFile(filename, "utf8", function(err, content) 
	{
		if (err) 
		{
			return console.log(err);
		}
  		res.send(content, null, 3);
//		console.log(content);
	});
	} else {
			var apiServerHost= 
'https://apx.cisco.com/spvss/infinitehome/ivptoolkit/clientrefapi/sandbox_0.4.1/contentInstances'+req._parsedUrl.search;
			res.redirect(apiServerHost);
	}
});







module.exports = router;
