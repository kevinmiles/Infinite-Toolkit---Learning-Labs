//When the page is properly loaded, 
//the pageLoaded() function will be automatically called
window.addEventListener('load', pageLoaded)

var limit = parseInt(cfg.limitChannelList);
var offset = 0;
var total = 0;


function makeBootStrapGrid(jsonObj) {
	// Create the list element:

	// Create the list item:


	var list = document.createElement('div');

	for (var i = 0; i < jsonObj.count; i++) {

		var row1 = document.createElement('div');

		if(i%4 === 3 || i===(jsonObj.count-1)) {
			row1.setAttribute("class", "row");
		}

		// Create the table element:
		var art = document.createElement('div');
		art.setAttribute("class", "col-sm-3");
		art.setAttribute("border", "3");
		art.setAttribute("bordercolor", "black");
		art.setAttribute("id", "sm3_"+i);

		var line0 = document.createElement('div');
		line0.setAttribute("class", "card-block");
		line0.setAttribute("align", "center");
		line0.setAttribute("id", "card_block_"+i);


		var divChannelName = document.createElement('msgAlert');
		divChannelName.setAttribute("class", "card-title");
		divChannelName.setAttribute("color", "black");
		divChannelName.setAttribute("align", "center");


		var msg = "";

		if (jsonObj.channels[i] !== undefined) {
			if (jsonObj.channels[i].logicalChannelNumber !== undefined) {
				msg+= jsonObj.channels[i].logicalChannelNumber;

			}
			if (jsonObj.channels[i].name !== undefined) {
				msg+= " - "+jsonObj.channels[i].name;
			}
			divChannelName.appendChild(document.createTextNode(msg));
		} else {
			divChannelName.setAttribute("bgcolor", "#FFAAAA");
			divChannelName.appendChild(document
					.createTextNode("logicalChannelNumber or name NOT FOUND"));

		}

		var divButtonWatch = document.createElement('button');
		divButtonWatch.setAttribute("class", "btn btn-success btn-block");
		divButtonWatch.setAttribute("onclick", "myFunctionPlaySession(this)");
		divButtonWatch.value= cfg.apiPlaySession + jsonObj.channels[i].id;
		msg = "Watch channel " + jsonObj.channels[i].logicalChannelNumber;
		divButtonWatch.appendChild(document.createTextNode(msg));

		var divButtonInfo = document.createElement('button');
		divButtonInfo.setAttribute("class", "btn btn-gray btn-block");
		divButtonInfo.setAttribute("onclick", "myDetailChannelInfo()");
		divButtonInfo.value= jsonObj.channels[i];
		divButtonInfo.appendChild(document.createTextNode("Channel Info"));
		divButtonInfo.setAttribute("vspace", "20");



		var divImg = document.createElement('div');
		if (jsonObj.channels[i].media !== undefined) {
			var elemImg = document.createElement('img');
			elemImg.setAttribute("src", jsonObj.channels[i].media[0].url);
			elemImg.setAttribute("height", "75");
			elemImg.setAttribute("vspace", "15");			
			divImg.appendChild(elemImg);
		}





		var divLineCollapse = document.createElement('div');
		divLineCollapse.setAttribute("class", "row");
		divLineCollapse.setAttribute("id", "line_"+i);


		var divPanelGroup = document.createElement('div');
		divPanelGroup.setAttribute("class", "panel-group");
		divPanelGroup.setAttribute("id", "accordion_"+i);
		divPanelGroup.setAttribute("aria-multiselectable", "true");
		divPanelGroup.setAttribute("role", "tablist");
		divPanelGroup.setAttribute("style", "background-color:green");

		// Add an accordion to display detailed channel infomation
		addChannelInfo(jsonObj,divPanelGroup,i);

		divLineCollapse.appendChild(divPanelGroup);

		line0.appendChild(divImg);
		line0.appendChild(divChannelName);
		line0.appendChild(divButtonWatch);


		art.appendChild(line0);
		art.appendChild(divLineCollapse);

		row1.appendChild(art);
		list.appendChild(row1);

	}


	// Finally, return the constructed list:
	return list;
}


function addChannelInfo(jsonObj,compo,counter) {

	var dataParent = '#accordion_'+counter;
	var ariaExpanded = false;
	var expandedClass = '';
	var collapsedClass = 'collapsed';
	var catgName = ' > Info about #'+jsonObj.channels[counter].logicalChannelNumber;


	var divHeadCol = document.createElement('div');
	divHeadCol.setAttribute("class", "col-md-12");
	divHeadCol.setAttribute("style", "margin-bottom: 0");

	var divPanelDef = document.createElement('div');
	divPanelDef.setAttribute("class", "panel panel-default");
	divPanelDef.setAttribute("id", "panel"+counter);

	var divPanelHead = document.createElement('div');
	divPanelHead.setAttribute("class", "panel-heading");
	divPanelHead.setAttribute("role", "tab");
	divPanelHead.setAttribute("id", "heading"+counter);

	var divPanelTitle = document.createElement('h6');
	divPanelTitle.setAttribute("class", "panel-title");

	var divPanelLabel = document.createElement('a');
	divPanelLabel.setAttribute("class", collapsedClass);
	divPanelLabel.setAttribute("id", 'panel-lebel'+counter);
	divPanelLabel.setAttribute("role", 'button');
	divPanelLabel.setAttribute("data-toggle", 'collapse');
	divPanelLabel.setAttribute("data-parent", dataParent);
	divPanelLabel.setAttribute("href", '#collapse_pan'+counter);
	divPanelLabel.setAttribute("aria-expanded", ariaExpanded);
	divPanelLabel.setAttribute("aria-controls", 'collapse_'+counter);
	var divPanelIcon = document.createElement('span');
	divPanelIcon.setAttribute("class", 'glyphicon glyphicon-list-alt');

	divPanelLabel.appendChild(divPanelIcon);
	divPanelLabel.appendChild(document.createTextNode(catgName));



	var divPanelCollpase = document.createElement('div');
	divPanelCollpase.setAttribute("class", 'panel-collapse collapse '+expandedClass);
	divPanelCollpase.setAttribute("id", 'collapse_pan'+counter);
	divPanelCollpase.setAttribute("role", 'tabpanel');
	divPanelCollpase.setAttribute("aria-labelledby", 'heading'+counter);
	divPanelCollpase.setAttribute("aria-controls", 'collapse_'+counter);

	var divPanelBody = document.createElement('div');
	divPanelBody.setAttribute("class", 'panel-body');
	divPanelBody.setAttribute("id", 'TextBoxDiv'+counter);

	var divPanelCol = document.createElement('div');
	divPanelCol.setAttribute("class", "col-md-12");
	divPanelCol.setAttribute("type", "test");


	var target = jsonObj.channels[counter];
	fillAttribute(divPanelCol,target);



//	PANEL HEAD
	divPanelTitle.appendChild(divPanelLabel);
	divPanelHead.appendChild(divPanelTitle);
	divPanelDef.appendChild(divPanelHead);


//	PANEL BODY
	divPanelBody.appendChild(divPanelCol);
	divPanelCollpase.appendChild(divPanelBody);
	divPanelDef.appendChild(divPanelCollpase);

	divHeadCol.appendChild(divPanelDef);
	compo.appendChild(divHeadCol);
}

//This function is in charge of parsing an JSON object
//coming from "channels" REF API request
//and build the result layout at HTML5 format:
function makeChannelListOld(jsonObj) {
	// Create the list element:
	var list = document.createElement('div');

	for (var i = 0; i < jsonObj.count; i++) {
		// Create the list item:
		var art = document.createElement('article');
		art.appendChild(document
				.createTextNode(jsonObj.channels[i].logicalChannelNumber
						+ "  -  " + jsonObj.channels[i].name));
		// Create a image element to display the channel logo
		var fig = document.createElement('channel_logo');
		var elem = document.createElement('img');
		elem.setAttribute("src", jsonObj.channels[i].media[0].url);
		// set fixed width and height 60x40
		elem.setAttribute("height", "40");
		elem.setAttribute("width", "60");
		fig.appendChild(elem);

		art.appendChild(fig);
		list.appendChild(art);
	}

	// Finally, return the constructed list:
	return list;
}



//This function is in charge of getting the channel list
//by using an XMLHttpRequest.
function getChannels() {
	var request = '';
	var xmlhttp = new XMLHttpRequest();

	// process answer update to request within "onreadystatechange" inner
	// function
	xmlhttp.onreadystatechange = function() {

		console.log("==> onreadystatechange readyState:"+xmlhttp.readyState+" / state:"+xmlhttp.status);
		if(xmlhttp.readyState === 4) {

			if (xmlhttp.status === 200 ) {
				messageLeftAlert("ID_DISPLAY", "JSON ANSWER = " + xmlhttp.responseText);
				obj = JSON.parse(xmlhttp.responseText);
				total = parseInt(obj.total);
				messageAlert("ID_RESULT", "FOUND " + obj.count + " OVER " + obj.total
						+ " CHANNELS");
				// parse the JSON answer and build a list layout
				// channel_list = makeDivcontent(obj);
				channel_list = makeBootStrapGrid(obj);

				document.getElementById("ID_RESULT").appendChild(channel_list);			
				$('#collapse2').collapse('show');
				$('#collapse1').collapse('hide');

			} else {


				if (xmlhttp.status === 0 ) {
					messageAlert("ID_ALERT", "TOKEN HAS EXPIRED");
					messageInput("ID_COMMENT", "Please try to reset the token by pressing green button");
					$('#collapse1').collapse('show');

				} else {
					messageRedAlert("ID_ALERT", "ANSWER TO REQUEST NOT RECEIVED");
					messageAlert("ID_COMMENT", "Unexpected error. STATUS = " + xmlhttp.status + " READY STATE = "
							+ xmlhttp.readyState+". Try to renew token. Expiration date:"+	checkTokenStatus() );
					$('#collapse1').collapse('show');
				}

			}

		}
	}

	xmlhttp.onerror = function(error) {
		messageRedAlert("ID_ALERT", "ERROR ON REQUEST");
		messageAlert("ID_COMMENT", "Unexpected error. STATUS = " + error.target.status);
		$('#collapse1').collapse('show');

	}

	var token = localStorage.getItem(cfg.storeAccesstoken);

	// request to get 25 first items of the channel list
	request = cfg.sandboxUrl + cfg.apiChannels + "?limit="+limit+"&offset="+offset;
	messageInput("ID_CHANNEL_REQUEST", "REQUEST  =  " + request);
	xmlhttp.open("GET", request, true);
	// Add token to the request header
	xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
	// send the request and wait answer in onreadystatechange callback
	xmlhttp.send();

}


function addPlayButton(component,IdChannelNumber) {
	// Create the table element:

	var art = document.createElement('button');
	art.setAttribute("onclick", "myFunctionPlaySession(this)");
	art.setAttribute("color", "green");
	art.innerHTML = "Watch channel "+IdChannelNumber;
	art.value= cfg.apiPlaySession + IdChannelNumber;
	component.appendChild(art);
}

function myFunctionPlaySession(evt) {
	if(evt.value !== undefined ) {
		console.log("PLAY LIVE: "+evt.value);
		getPlaySessionInfo(evt.value);
	}
}


function getPlaySessionInfo(playSessionQuery) {
	var request = '';
	var xmlhttp = new XMLHttpRequest();
	console.log("PLAY SESSION : " + playSessionQuery);

	xmlhttp.onError = function() {
		messageRedAlert("ID_COMMENT", "HTTP ERROR = " + xmlhttp.status);
		console.log("xmlhttp.onError xmlhttp.status  : " + xmlhttp.status+ " / readyState: " + xmlhttp.readyState);	
	}

	xmlhttp.onreadystatechange = function() {
		console.log("xmlhttp.onreadystatechange xmlhttp.status  : " + xmlhttp.status+ " / readyState: " + xmlhttp.readyState);	


		if (xmlhttp.status === 500 && xmlhttp.readyState === 4) {
			console.log("READY TO PLAY default video ==> "+cfg.playDefault);
			messageH2("ID_DISPLAY", "ANSWER not found uses default video ==> "+cfg.playDefault);
			localStorage.removeItem(cfg.storePlayUrl);
			localStorage.setItem(cfg.storePlayUrl, cfg.playDefault);
			window.location.href=cfg.linkLiveTv;
		}


		if (xmlhttp.status === 200 && xmlhttp.readyState === 4) {
			messageH5("ID_DISPLAY", "JSON ANSWER = " + xmlhttp.responseText);
			obj = JSON.parse(xmlhttp.responseText);
			if (obj._links !== undefined && obj._links.playUrl !== undefined) {
				messageH2("ID_RESULT", "PLAY " + obj._links.playUrl.href);
				console.log("READY TO PLAY  : " + obj._links.playUrl.href);
				localStorage.removeItem(cfg.storePlayUrl);
				localStorage.setItem(cfg.storePlayUrl, obj._links.playUrl.href);
				window.location.href=cfg.linkLiveTv;
			}  else {
				console.log("PROBLEM TO PLAY  : " + obj._links);

			}
		}
	}

	token = localStorage.getItem(cfg.storeAccesstoken);

	if (token !== null) {
		request = cfg.sandboxUrl + playSessionQuery;
		messageH2("ID_TOKEN", "TOKEN = " + token);
		messageH2("ID_TOKEN_REQUEST", "REQUEST  =  " + request);
		xmlhttp.open("POST", request, true);
		xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
		console.log("SEND REQUEST: "+request);
		try {
			xmlhttp.send();				
		} catch (err) {
			console.log("TRY CATCH ERROR: "+err);
		}
	} else {
		var msg = "TOKEN = No Token defined. Enter your Token ID first.";
		// messageH2("ID_TOKEN", msg);
		messageRedAlert("ID_ALERT",msg);
		$('#collapse1').collapse();

	}
}

//This function is called at each page loading.
function pageLoaded() {
	console.log("Channel list pageLoaded");
	parseUrl();
	updateRootPath();
	addToogleIcon("ID_TokenCollapse");
	checkConfig(cfg.redirectChannelList, getChannels);
}


//function called when Submit button is pressed
function myResetRequest() {
	offset = 0;
	limit = parseInt(cfg.limitChannelList);
	document.getElementById("ID_CHANNEL_LIST_OFFSET").value=""+offset;
	document.getElementById("ID_CHANNEL_LIST_LIMIT").value=""+limit;
}

//function called when Submit button is pressed
function mySubmitRequest() {

	var val = parseInt(document.getElementById("ID_CHANNEL_LIST_OFFSET").value);
	var process = true;

	if(val >= 0 && val < 2556) {
		offset = val;
	} else {
		document.getElementById("ID_CHANNEL_LIST_OFFSET").value="Please ENTER a valid value between 0 and 255";
		process=false
	}

	val = parseInt(document.getElementById("ID_CHANNEL_LIST_LIMIT").value);
	if(val >= 0 && val < 2556) {
		limit = val;
	} else {
		document.getElementById("ID_CHANNEL_LIST_LIMIT").value="Please ENTER a valid value between 0 and 255";
		process=false
	}


	if(process) {
		console.log("==> CALL getChannels with offset=" + offset+" and limit="+limit);
		getChannels();
	} 
}


//function called when Previous Page button is pressed
function myFunctionPreviousPageChannelList() {
	if(offset-limit>=0) {
		offset-=limit;
		getChannels();
	}
}

//function called when Next Page button is pressed
function myFunctionNextPageChannelList() {
	if(offset+limit<total) {
		offset+=limit;
		getChannels();
	}
	console.log("NEW offset: " + offset);
}


//function called when Next Page button is pressed
function myNav2VOD() {
	window.location.href=cfg.linkLiveTv;
}




