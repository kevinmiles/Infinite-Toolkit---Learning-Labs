# SampleApps_HTML5
Sample applications showing REF API examples (channel list, Vod catalogue, Store categories, ...)
Version V1.0.0

|-- sample_apps_html5/        ==> main directory
        |-- channelList/      ==> Sample App displaying the channel list 
        |-- css/              ==> *.css
        |-- fonts/            ==> FontAwesome font (otf, ttf, woff, svg)
        |-- js/               ==> java script including jquery.scrollTo
        |-- landingPage/      ==> home page develop for multi device with BootStrap
        |-- tokenManager/     ==> Sample App showing token management

      
## SampleApps_HTML5 : user manual - Installation for a local test
1. Go the main directory sampleAppsHtml5
2. Set and launch a local web server (eg on port 8000) 
	For Mac OS, it’s embedded, from your folder, in a terminal : launch « python -m SimpleHTTPServer 8000 »
3. Then access the server from any browser at localhost:8000 (should be compatible for all)
4. For public access, go to http://sample-apps.spvss-infinitetoolkit.ciscolabs.com and chose your sample app