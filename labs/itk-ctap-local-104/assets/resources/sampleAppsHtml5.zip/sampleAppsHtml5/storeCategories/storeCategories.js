//When the page is properly loaded, 
//the pageLoaded() function will be automatically called

window.addEventListener('load', pageLoaded);

var vodCategoriesDiscovery = false;
var startLocator = null;
var endLocator = null;
var offsetLocator = null;
var pageLinks = null;

var limit = cfg.limitVodCatalague;
var offset = 0;
var sandboxUrl = null;

function addCategoriesOption(name,id) {

	var opt = document.createElement('option');
	opt.value = id;
	opt.innerHTML = name;
	document.getElementById("ID_VOD_SelectCategory").appendChild(opt);
}

//This function is in charge of parsing an JSON object
//coming from "content" REF API request
//and build the result layout at HTML5 table:
function addCategoriesList(jsonObj) {

	if (jsonObj.leaf === true) {
		console.log("ADD VOD CATEGORIES : " + jsonObj.leaf + "/ "
				+ jsonObj.name + " [ID = " + jsonObj.id + " ]");
		addCategoriesOption(jsonObj.name,jsonObj.id);
	} else {
		console.log("GO DEEPER IN CATEGORY : " + jsonObj.id);
		getVodCategories(cfg.apiCategories + "/" + jsonObj.id);
	}

}

//The purpose of this function is to dynamically
//find all genres by browsing categories tree.
function getVodCategories(categoryQuery) {
	var request = '';
	var xmlhttp = new XMLHttpRequest();

	console.log("VOD CATEGORIES : " );

	xmlhttp.onreadystatechange = function() {
		messageH3("ID_STATUS", "STATUS = " + xmlhttp.status + " READY STATE =" + xmlhttp.readyState);

		if (xmlhttp.status === 200 && xmlhttp.readyState === 4) {
			// messageH3("ID_DISPLAY", "JSON ANSWER = " + xmlhttp.responseText);
			obj = JSON.parse(xmlhttp.responseText);
			if (obj.count !== undefined && obj.categories !== undefined
					&& obj.count > 0) {
				for (var i = 0; i < obj.count; i++) {
					addCategoriesList(obj.categories[i]);
				}
			} else {
				addCategoriesList(obj);
			}
		}
	}

		token = localStorage.getItem(cfg.storeAccesstoken);
		sandboxUrl= cfg.sandboxUrl;

	

	console.log("VOD CATALOGUE TOKEN: " + token);
	console.log("VOD CATALOGUE sandboxUrl: " + sandboxUrl);
	// token="HACKATHON";
	if (token !== null) {
		if(categoryQuery !== undefined) {
				console.log("VOD CATALOGUE categoryQuery: " + categoryQuery);

			request = sandboxUrl + categoryQuery;

		} else
		{
			
				console.log("VOD CATALOGUE cfg.apiCategories: " + cfg.apiCategories);


			request = sandboxUrl + cfg.apiCategories;
		}

		messageH3("ID_TOKEN", "TOKEN = " + token);
		messageH3("ID_REQUEST", "REQUEST  =  " + request);
		xmlhttp.open("GET", request, true);
		xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
		// xmlhttp.setRequestHeader("x-cisco-vcs-identity", cfg.cisco_identity);

		console.log("STORE CATEGORIES SEND REQUEST: "+request);
		xmlhttp.send();
	} else {
		var msg = "TOKEN = No Token defined. Please go to Token Manager Sample App first";
		messageH3("ID_TOKEN", msg);
		alert(msg);
	}
}

//The HLS m3u8 URL is found by following POST request
//If found, the browser load the play HLS stream page
function getPlaySessionInfo(playSessionQuery) {
	var request = '';
	var xmlhttp = new XMLHttpRequest();
	//console.log("PLAY SESSION : " + playSessionQuery);

	xmlhttp.onreadystatechange = function() {

		if (xmlhttp.status === 200 && xmlhttp.readyState === 4) {
			messageLeftAlert("ID_DISPLAY", "JSON ANSWER = " + xmlhttp.responseText);
			obj = JSON.parse(xmlhttp.responseText);
			if (obj._links !== undefined && obj._links.playUrl !== undefined) {
				messageH3("ID_RESULT", "PLAY " + obj._links.playUrl.href);
				console.log("READY TO PLAY  : " + obj._links.playUrl.href);

				// store PlayUrl to use it within video playback page
				//localStorage.removeItem(cfg.storePlayUrl);
				localStorage.setItem(cfg.storePlayUrl, obj._links.playUrl.href);
				// store ID to use it at delete session
				localStorage.setItem(cfg.playSessionID, obj.id);

				window.location.href=cfg.linkLiveTv;

			}  else {
				console.log("PROBLEM TO PLAY  : " + obj._links);

			}
		}
	}

		token = localStorage.getItem(cfg.storeAccesstoken);
		sandboxUrl= cfg.sandboxUrl;


	if (token !== null) {
		request = sandboxUrl + playSessionQuery;
		messageH3("ID_TOKEN", "TOKEN = " + token);
		messageH3("ID_REQUEST", "REQUEST  =  " + request);
		xmlhttp.open("POST", request, true);
		xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
		// xmlhttp.setRequestHeader("x-cisco-vcs-identity", cfg.cisco_identity);
		console.log("VOD CATALOGUE SEND REQUEST #2: "+request);
		xmlhttp.send();
	} else {
		var msg = "TOKEN = No Token defined. Please go to Token Manager Sample App first";
		messageH3("ID_TOKEN", msg);
		alert(msg);
	}
}


//Add a play button. 
//The play session link is stored in value field 
function addPlayButton(component,jsonObj) {
	// Create the table element:
	if (jsonObj.type !== undefined) {

		var art = document.createElement('button');
		art.setAttribute("onclick", "myFunctionPlaySession(this)");

		if (jsonObj.type === "vod" && jsonObj._links !== undefined 
				&& jsonObj._links.playSession !== undefined) {
			art.innerHTML = "ADD RENT IT NOW !";
			art.value=jsonObj._links.playSession.href;

		}

		if (jsonObj.type === "event" && jsonObj.channel !== undefined) {
			art.innerHTML = "PLAY IT NOW !";
			art.value=cfg.apiPlaySession+jsonObj.channel.id;
		}

		if (jsonObj.type === "pvr") {
			art.innerHTML = "START PLAYBACK !";
		}
		component.appendChild(art);

		/*
		if (jsonObj.type === "vod") {
			var watchlist = document.createElement('button');
			watchlist.setAttribute("onclick", "myFunctionPlaySession(this)");
			if(selectCategory === 'WATCHLIST_ID') {
				watchlist.innerHTML = "REMOVE TO WATCHLIST";

			} else {
				watchlist.innerHTML = "ADD TO WATCHLIST";

			}
			component.appendChild(watchlist);
		}
		 */

	}

}

//Create HTML table to display VOD catalogue result


function makeBootStrapGrid(jsonObj) {
	// Create the list element:

	// Create the list item:


	var list = document.createElement('div');

	for (var i = 0; i < jsonObj.count; i++) {

		var row1 = document.createElement('div');
		var asset = jsonObj.content[i];
		while(asset.type!=='vod' && i<jsonObj.count) {
			i++;
			var asset = jsonObj.content[i];
		}
		if(i%4 === 3 || i===(jsonObj.count-1)) {
			row1.setAttribute("class", "row");
		}

		// Create the table element:
		var art = document.createElement('div');
		art.setAttribute("class", "col-sm-3");
		art.setAttribute("border", "3");
		art.setAttribute("bordercolor", "black");
		art.setAttribute("id", "sm3_"+i);

		var line0 = document.createElement('div');
		line0.setAttribute("class", "card-block");
		line0.setAttribute("align", "center");
		line0.setAttribute("id", "card_block_"+i);


		var divChannelName = document.createElement('msgAlert');
		divChannelName.setAttribute("class", "card-title");
		divChannelName.setAttribute("color", "black");
		divChannelName.setAttribute("align", "center");


		var msg = "";

		if (asset.content !== undefined) {
			if (asset.content.title !== undefined) {
				msg+= asset.content.title;
			}


			divChannelName.appendChild(document.createTextNode(msg));
		} else {
			divChannelName.setAttribute("bgcolor", "#FFAAAA");
			divChannelName.appendChild(document
					.createTextNode("title NOT FOUND"));

		}


		var divButtonWatch = document.createElement('button');
		divButtonWatch.setAttribute("class", "btn btn-warning btn-block");
		divButtonWatch.setAttribute("onclick", "myFunctionPlaySession(this)");		
		msg = "Can't play it " ;
		var img = cfg.orangeIcon;

		// console.log("==> ASSET TYPE:"+asset.type);
		if (asset.type === "vod" && asset.content !== undefined && asset._links !== undefined 
				&& asset._links.playSession !== undefined) {
			divButtonWatch.value=asset._links.playSession.href;
			divButtonWatch.setAttribute("class", "btn btn-success ");
			divButtonWatch.setAttribute("hspace", "10");

			msg = "Watch it now";
			img = asset.content.media[0].url;
		}

		if (asset.type === "event" && asset.content !== undefined) {
			if(asset.channel !== undefined) {
				divButtonWatch.value=cfg.apiPlaySession+asset.channel.id;


			} else {
				divButtonWatch.value=asset._links.self.href;

			}
			divButtonWatch.setAttribute("class", "btn btn-success btn-block");
			msg = "Watch it now";
			if (asset.content.media !== undefined) {
				img = asset.content.media[0].url;				
			} 
		}

		if (asset.type === "pvr" && asset.content !== undefined && asset._links !== undefined) {
			divButtonWatch.setAttribute("class", "btn btn-success btn-block");
			msg = "Start play back" ;
			img = asset.content.media[0].url;
			divButtonWatch.value=asset._links.self.href;
		}
		divButtonWatch.appendChild(document.createTextNode(msg));



		if (asset.type === "vod" && asset.content !== undefined) {
			var selectCategory = document.getElementById("ID_VOD_SelectCategory").value;

			var divButtonWatchList = document.createElement('button');

			if(selectCategory !== 'WATCHLIST_ID') {
				divButtonWatchList.setAttribute("class", "btn btn-success ");
				divButtonWatchList.setAttribute("onclick", "myFunctionAddToWatchlist(this)");		
				msg = "Add to WatchList" ;
			} else {
				divButtonWatchList.setAttribute("class", "btn btn-warning ");
				divButtonWatchList.setAttribute("onclick", "myFunctionRemoveFromWatchlist(this)");		
				msg = "Del from List" ;	
			}
			// divButtonWatchList.value=asset._links.self.href;
			divButtonWatchList.appendChild(document.createTextNode(msg));
		}


		/*		
		var divButtonInfo = document.createElement('button');
		divButtonInfo.setAttribute("class", "btn btn-gray btn-block");
		divButtonInfo.setAttribute("onclick", "myDetailAssetInfo()");
		divButtonInfo.value= asset.content;
		divButtonInfo.appendChild(document.createTextNode("Asset Info"));
		divButtonInfo.setAttribute("vspace", "20");
		 */


		var divImg = document.createElement('div');

		if (img !== undefined) {
			var elemImg = document.createElement('img');
			elemImg.setAttribute("src", img);
			elemImg.setAttribute("height", "135");
			elemImg.setAttribute("vspace", "15");			
			divImg.appendChild(elemImg);
		}



		var divLineRow = document.createElement('div');
		divLineRow.setAttribute("class", "row");

		/*
		var divLineCollapse = document.createElement('div');
		divLineCollapse.setAttribute("class", "row");
		divLineCollapse.setAttribute("id", "line_"+i);

/*
		var divPanelGroup = document.createElement('div');
		divPanelGroup.setAttribute("class", "panel-group");
		divPanelGroup.setAttribute("id", "accordion_"+i);
		divPanelGroup.setAttribute("aria-multiselectable", "true");
		divPanelGroup.setAttribute("role", "tablist");
		divPanelGroup.setAttribute("style", "background-color:green");

		// Add an accordion to display detailed channel infomation
		// addChannelInfo(jsonObj,divPanelGroup,i);
		divLineCollapse.appendChild(divPanelGroup);

		 */


		line0.appendChild(divImg);
		line0.appendChild(divButtonWatch);
		line0.appendChild(divButtonWatchList);
		line0.appendChild(divLineRow);
		line0.appendChild(divChannelName);


		art.appendChild(line0);
		//art.appendChild(divLineCollapse);

		row1.appendChild(art);
		list.appendChild(row1);

	}


	// Finally, return the constructed list:
	return list;
}


function addChannelInfo(jsonObj,compo,counter) {

	var dataParent = '#accordion_'+counter;
	var ariaExpanded = false;
	var expandedClass = '';
	var collapsedClass = 'collapsed';
	var catgName = ' > More Info ';


	var divHeadCol = document.createElement('div');
	divHeadCol.setAttribute("class", "col-md-12");
	divHeadCol.setAttribute("style", "margin-bottom: 0");

	var divPanelDef = document.createElement('div');
	divPanelDef.setAttribute("class", "panel panel-default");
	divPanelDef.setAttribute("id", "panel"+counter);

	var divPanelHead = document.createElement('div');
	divPanelHead.setAttribute("class", "panel-heading");
	divPanelHead.setAttribute("role", "tab");
	divPanelHead.setAttribute("id", "heading"+counter);

	var divPanelTitle = document.createElement('h6');
	divPanelTitle.setAttribute("class", "panel-title");

	var divPanelLabel = document.createElement('a');
	divPanelLabel.setAttribute("class", collapsedClass);
	divPanelLabel.setAttribute("id", 'panel-lebel'+counter);
	divPanelLabel.setAttribute("role", 'button');
	divPanelLabel.setAttribute("data-toggle", 'collapse');
	divPanelLabel.setAttribute("data-parent", dataParent);
	divPanelLabel.setAttribute("href", '#collapse_pan'+counter);
	divPanelLabel.setAttribute("aria-expanded", ariaExpanded);
	divPanelLabel.setAttribute("aria-controls", 'collapse_'+counter);
	var divPanelIcon = document.createElement('span');
	divPanelIcon.setAttribute("class", 'glyphicon glyphicon-list-alt');

	divPanelLabel.appendChild(divPanelIcon);
	divPanelLabel.appendChild(document.createTextNode(catgName));



	var divPanelCollpase = document.createElement('div');
	divPanelCollpase.setAttribute("class", 'panel-collapse collapse '+expandedClass);
	divPanelCollpase.setAttribute("id", 'collapse_pan'+counter);
	divPanelCollpase.setAttribute("role", 'tabpanel');
	divPanelCollpase.setAttribute("aria-labelledby", 'heading'+counter);
	divPanelCollpase.setAttribute("aria-controls", 'collapse_'+counter);

	var divPanelBody = document.createElement('div');
	divPanelBody.setAttribute("class", 'panel-body');
	divPanelBody.setAttribute("id", 'TextBoxDiv'+counter);

	var divPanelCol = document.createElement('div');
	divPanelCol.setAttribute("class", "col-md-12");
	divPanelCol.setAttribute("type", "test");


	var target = jsonObj.content[counter].content;

	fillAttribute(divPanelCol,target);


//	PANEL HEAD
	divPanelTitle.appendChild(divPanelLabel);
	divPanelHead.appendChild(divPanelTitle);
	divPanelDef.appendChild(divPanelHead);


//	PANEL BODY
	divPanelBody.appendChild(divPanelCol);
	divPanelCollpase.appendChild(divPanelBody);
	divPanelDef.appendChild(divPanelCollpase);

	divHeadCol.appendChild(divPanelDef);
	compo.appendChild(divHeadCol);
}




//The purpose of this function is to find the asset list 
//according to different options set in the Vod Catalogue page.
function getVodCatalogue() {
	var request = '';
	var xmlhttp = new XMLHttpRequest();

	console.log("VOD CATALOGUE : ");
	if(!vodCategoriesDiscovery) {
		getVodCategories();
		vodCategoriesDiscovery=true;
	}

	xmlhttp.onerror = function(error) {
		messageRedAlert("ID_ALERT", "ERROR ON REQUEST");
		messageAlert("ID_COMMENT", "Unexpected error. STATUS = " + error.target.status);
		$('#collapse1').collapse('show');

	}

	xmlhttp.onreadystatechange = function() {
		//console.log("ID_STATUS", "STATUS = " + xmlhttp.status + " READY STATE = "
		//		+ xmlhttp.readyState);

		if( xmlhttp.readyState === 4) {

			if (xmlhttp.status === 200) {
				messageLeftAlert("ID_DISPLAY", "JSON ANSWER = " + xmlhttp.responseText);
				obj = JSON.parse(xmlhttp.responseText);
				messageAlert("ID_RESULT", "FOUND " + obj.count + " OVER " + obj.total
						+ " Contents");

				catalogueList = makeBootStrapGrid(obj);

				if (obj.locators !== undefined) {
					endLocator = obj.locators.end;
					startLocator = obj.locators.start;
					pageLinks = obj;
				}
				document.getElementById("ID_RESULT").appendChild(catalogueList);
				$('#collapse2').collapse('show');
				$('#collapse1').collapse('hide');
			} else {

				if (xmlhttp.status === 0 ) {
					messageAlert("ID_ALERT", "TOKEN HAS EXPIRED");
					messageInput("ID_COMMENT", "Please try to reset the token by pressing green button");
					$('#collapse1').collapse('show');
				} else {
					messageRedAlert("ID_ALERT", "ANSWER TO REQUEST NOT RECEIVED");
					messageAlert("ID_COMMENT", "Unexpected error. STATUS = " + xmlhttp.status + " READY STATE = "
							+ xmlhttp.readyState);
					$('#collapse1').collapse('show');
				}

			}
		}
	}

		token = localStorage.getItem(cfg.storeAccesstoken);
		sandboxUrl= cfg.sandboxUrl;


	console.log("VOD CATALOGUE TOKEN: " + token);
	if (token !== null) {

		var selectedType = document.getElementById("ID_VOD_SelectType").value;

		var selectedSort = document.getElementById("ID_VOD_SelectSort").value;

		var selectCategory = document.getElementById("ID_VOD_SelectCategory").value;

		var contentQuery = cfg.apiContentInstances;

		contentQuery += "?limit=" + limit;
		contentQuery += "&offset=" + offset;

		if (selectCategory !== "all") {
			contentQuery += "&categoryId=" + selectCategory;
		}

		if (selectedType !== "all") {
			contentQuery += "&source=" + selectedType;
		}
		if (selectedSort !== "none") {
			contentQuery += "&sort=" + selectedSort;
		}

		if (offsetLocator !== null) {
			contentQuery += "&locator=" + encodeURIComponent(offsetLocator);
		}

		var isAdultFilter = document.getElementById("isAdult").checked;
		var isErotic = document.getElementById("isErotic").checked;

		if (isAdultFilter === true) {
			contentQuery += "&isAdult=true";
		}

		if (isErotic === true) {
			contentQuery += "&isErotic=true";
		}

		var inputKeyword = document.getElementById("inputKeyword").value;
		console.log("SELECTED inputKeyword: " + inputKeyword);

		if (inputKeyword.length > 0) {
			contentQuery += "&q=" + inputKeyword;
		}

		/*
		if(selectCategory === 'WATCHLIST_ID') {
			request = sandboxUrl + cfg.apiContentInstances+'/all';		
			console.log("Expect to be handle by helloworld: " + request);
		}
		else {
			request = sandboxUrl + contentQuery;			
		}
		*/

		request = sandboxUrl + contentQuery;			
		messageInput("ID_VOD_REQUEST", "REQUEST  =  " + request);

		xmlhttp.open("GET", request, true);
		xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
		// xmlhttp.setRequestHeader("x-cisco-vcs-identity", cfg.cisco_identity);

		console.log("VOD CATALOGUE SEND REQUEST #1: "+request);
		console.log("VOD CATALOGUE HEADER: "+cfg.cisco_identity);
		console.log("VOD CATALOGUE selectCategory: "+selectCategory);

		xmlhttp.send();
	} else {
		var msg = "TOKEN = No Token defined. Please go to Token Manager Sample App first";
		messageH3("ID_TOKEN", msg);
		alert(msg);
	}
}

//This function is called at each page loading.
function pageLoaded() {
	console.log("store categories pageLoaded");

	parseUrl();
	sessionStorage.setItem(cfg.storeRedirectUri,rootPath+cfg.redirectstoreCategories);

	updateRootPath();
	addToogleIcon("ID_TokenCollapse");

	var rootPath = sessionStorage.getItem(cfg.storeRootPath);
	// localStorage.removeItem(cfg.storeAccesstoken);
	// sessionStorage.setItem(cfg.storeRedirectUri,rootPath+cfg.redirectstoreCategories);
	console.log("==> DGB storeRedirectUri:"+sessionStorage.getItem(cfg.storeRedirectUri));
	console.log("==> DGB useTokenAccess:"+cfg.useTokenAccess);

	if(cfg.useTokenAccess ==='yes') {
		console.log("==> DGB checkConfig:");

		checkConfig(cfg.redirectstoreCategories, getVodCatalogue);
	} else {
		getVodCatalogue();		
	}

}

//This function is in charge checking Token validity 
//before requesting channel list.

//function called when PLAY button is pressed
function myFunctionPlaySession(evt) {
	if(evt.value !== undefined ) {
		console.log("PLAY LIVE: "+evt.value);
		getPlaySessionInfo(evt.value);
	}

}

//function called when Submit button is pressed
function myResetRequest() {
	offsetLocator = null;
	offset = 0;
	limit = parseInt(cfg.limitChannelList);
	document.getElementById("ID_VOD_OFFSET").value=""+offset;
	document.getElementById("ID_VOD_LIMIT").value=""+limit;
}


//function called when Submit button is pressed
function mySubmitRequest() {
	offsetLocator = null;
	getVodCatalogue();
}

//function called when Previous Page button is pressed
function myFunctionPreviousPageVodCatalogue() {
	if(offset-limit>=0 && startLocator !== undefined) {		
		offsetLocator = startLocator;
		offset=-limit;
		getVodCatalogue();
	}

}

//function called when Next Page button is pressed
function myFunctionNextPageVodCatalogue() {
	if(endLocator !== undefined) {		
		offsetLocator = endLocator;
		offset=1;
		getVodCatalogue();
	}
}