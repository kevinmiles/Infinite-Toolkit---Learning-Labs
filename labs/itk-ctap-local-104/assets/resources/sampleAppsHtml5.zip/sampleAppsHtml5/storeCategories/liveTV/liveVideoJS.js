//videojs.autoSetup();

videojs('player_video_id').ready(function(){

	// Store the video object
	var myPlayer = this;
	var myPlayerIsPlaying=false;	

	var id = myPlayer.id();
	// Make up an aspect ratio
	var aspectRatio = 264/640; 

	function stopPlayer(){
		console.log("stopPlayer ");
		if(myPlayerIsPlaying) {
			myPlayer.dispose();
			
			myPlayerIsPlaying=false;	
			deletePlaySession();		
		}
	}


	function resizeVideoJS(){
		var width = document.getElementById(id).parentElement.offsetWidth;
		myPlayer.width(width).height( width * aspectRatio );

	}

	function playVideoJS(){
		var width = document.getElementById(id).parentElement.offsetWidth;
		myPlayer.width(width).height( width * aspectRatio );

		var playUrl = localStorage.getItem(cfg.storePlayUrl);
		messageAlert("ID_STREAM","Now playing "+playUrl);
		console.log("Try to play URL:"+playUrl);

		// Play expected stream
		if(playUrl) {
			try {
				myPlayer.src({
					src : playUrl,
					type: 'application/x-mpegURL'
				});		
				myPlayer.play();
				myPlayerIsPlaying=true;
			} catch(err) {
				console.log("Error found in try catch "+err);
			}
		}


	}




	// when stoping the player, a DELETE request 
	// should be sent to delete the playback session
	function deletePlaySession() {
		var request = '';
		var playSessionID = localStorage.getItem(cfg.playSessionID);
		var xmlhttp = new XMLHttpRequest();
		console.log("==> Delete Session");

		xmlhttp.onreadystatechange = function() {

			if (xmlhttp.status === 200 && xmlhttp.readyState === 4) {
				console.log("<== Session Deleted");
			}
		}

		var token = localStorage.getItem(cfg.storeAccesstoken);

		request = cfg.sandboxUrl + cfg.apiPlayVodSession + "/" + playSessionID;
		xmlhttp.open("DELETE", request, true);
		xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
		// console.log("VOD CATALOGUE SEND REQUEST: "+request);
		xmlhttp.send();
	}

	function registerOnClickButton() {

		document.getElementById("myBtn").addEventListener("click", function(){
			stopPlayer();
		});

	}

	// Main Program
	
	// Register the player to listen 'Stop Player' button press
	registerOnClickButton();
	
	// Initialize resizeVideoJS()
	playVideoJS();

	// On resizing window ==> call resizeVideoJS()
	window.onresize = resizeVideoJS; 

	// On leaving browser or video page ==> call resistopPlayerzeVideoJS()
	window.onbeforeunload = stopPlayer; 


});