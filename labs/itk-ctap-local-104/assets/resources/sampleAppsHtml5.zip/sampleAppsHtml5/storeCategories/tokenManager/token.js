// When the page is properly loaded, 
// the startApplication() function will be automatically called
window.addEventListener('load', pageLoaded)
// window.onload = parseURL;
// could be also used but is less supported by older browser


// This function is in charge of getting a new token by calling
// implicitGrant function
// Client ID is change if something is found in corresponding input field.
// Client ID information is stored in persistent session storage.
function myFunctionResetToken() {

	imgUp("token_img" , cfg.purpleIcon);
	imgUp("refapi_img", cfg.purpleIcon);

	messageH5("token_1", "STATUS : Token renew in progress !");
	messageH5("token_2", "Please Wait ...");

	var clientId = document.getElementById("inputClientId").value;

	messageH5("refapi_1", "NEW CLIENT ID " + clientId);
	messageH5("refapi_2", "");

	if (clientId.length > 0) {
		console.log("New CLIENT ID: " + clientId);
		localStorage.removeItem(cfg.storeClientId);
		localStorage.setItem(cfg.storeClientId, clientId);
	}


	// reset persistent token
	var rootPath = sessionStorage.getItem(cfg.storeRootPath);
	localStorage.removeItem(cfg.storeAccesstoken);
	sessionStorage.setItem(cfg.storeRedirectUri,rootPath+cfg.redirectTokenManager);
	// Generate new token
	implicitGrant();
}

// This function is in charge of testing a simple REF API
// corresponding to the 2 first channels of the channellist.
function testRefApi() {
	var request = '';
	var xmlhttp = new XMLHttpRequest();

	xmlhttp.onerror = function(error) {
		messageH5("refapi_1", "ERROR STATUS = " + error);
		messageH5("refapi_2", "ERROR STATUS = " + xmlhttp.status
				+ " READY STATE = " + xmlhttp.readyState);
		errorReason(xmlhttp, xmlhttp.status);
	};

	xmlhttp.onreadystatechange = function() {
		messageH5("refapi_2", "STATUS = " + xmlhttp.status + " READY STATE = "
				+ xmlhttp.readyState);

		if (xmlhttp.status === 200 && xmlhttp.readyState === 4) {
			messageH5("ID_DISPLAY", "JSON ANSWER = " + xmlhttp.responseText);
			imgUp("refapi_img", cfg.greenIcon);
		} else {
			imgUp("refapi_img", cfg.orangeIcon);
		}
	}

	token = localStorage.getItem(cfg.storeAccesstoken);

	if (token !== null) {
		request = cfg.sandboxUrl+ cfg.apiChannels + "?limit=2"
		messageH5("token_2", "TOKEN = " + token);
		messageH5("refapi_1", "REQUEST = " + request);

		console.log("REQUEST in progress");

		xmlhttp.open("GET", request, true);
		xmlhttp.setRequestHeader("Authorization", "Bearer " + token);
		try {
			xmlhttp.send();
		} catch (err) {
			messageH5("refapi_1", "Error = " + err);
		}

	}
}


//This function is called at each page loading.
function pageLoaded() {
	console.log("Token manager pageLoaded");
	updateRootPath();
	parseUrl();
	startApplication();
}


function startApplication() {

	imgUp("token_img", cfg.orangeIcon);
	messageH5("token_0", "CLIENT_ID = " + localStorage.getItem(cfg.storeClientId));

	var expDate = checkTokenStatus();
	console.log("start Token Application exp date:" + expDate);

	// Token status is not a persistent information. Better use session storage
	var tokenState = sessionStorage.getItem(cfg.storeTokenStatus);
	console.log("PARSE URL tokenState " + tokenState);
	var rootPath = sessionStorage.getItem(cfg.storeRootPath);

	//var expirationDate = new Date();
	//expirationDate.setSeconds(6000);
	//localStorage.setItem(cfg.storeExpirationDate, expirationDate.getTime());
	//console.log("start Token Application New exp date:" + expirationDate);

	
	switch (parseInt(tokenState)) {

	case tokenStateEnum.ROOT_PATH_NOT_FOUND:
		var error_messageH5 = "WARNING ! Wrong base URL. Should never happen !";
		imgUp("refapi_img",  cfg.orangeIcon);
		messageH5("refapi_1", error_messageH5);
		messageAlert("alertID",error_messageH5);
		break;

	case tokenStateEnum.CLIENT_ID_NOT_FOUND:
		var error_messageH5 = "WARNING ! You didn't enter Client ID  yet. Please do it NOW !";
		console.log("TOKEN_NOT_FOUND ==> rootPath: "+rootPath);

		imgUp("token_img", cfg.redIcon);
		messageH5("token_2", "TOKEN = No token so far !");
		imgUp("refapi_img",  cfg.orangeIcon);
		messageH5("refapi_1", error_messageH5);
		messageAlert("alertID",error_messageH5);
		break;

	case tokenStateEnum.TOKEN_READY:
		messageH5("token_1",
				"STATUS : A valid token is available. <br>It will expire at "
				+ expDate);

		messageH5("token_2", "accesstoken:"
				+ localStorage.getItem(cfg.storeAccesstoken));

		imgUp("token_img",  cfg.greenIcon);
		testRefApi();
		break;

	case tokenStateEnum.TOKEN_EXPIRED:
		var error_messageH5 = "STATUS : Your token has expired since "
			+ expDate;
		imgUp("token_img",  cfg.redIcon);
		messageH5("token_1", error_messageH5);
		messageAlert("alertID",error_messageH5 + " You must renew it by pressing 'Token reset'");
		break;

	case tokenStateEnum.TOKEN_NOT_FOUND:
		console.log("TOKEN_NOT_FOUND ==> rootPath: "+rootPath);

		imgUp("token_img", cfg.redIcon);
		messageH5("token_2", "TOKEN = No token so far !");
		console.log("TOKEN_NOT_FOUND ==> implicitGrant: ");
		sessionStorage.setItem(cfg.storeRedirectUri,rootPath+cfg.redirectTokenManager);
		console.log("storeRedirectUri ==> : "+sessionStorage.getItem(cfg.storeRedirectUri));
		//implicitGrant();

		break;

	default:
		console.log("CASE BAD VALUE: " + tokenState + " / "
				+ tokenStateEnum.TOKEN_NOT_FOUND);
	break;

	}
}
