var cfg = {
		"limitChannelList":"16",
		"limitVodCatalague":"16",
		"useTokenAccess":"yes",
		"authUrl": "https://cloudsso.cisco.com/as/authorization.oauth2?response_type=token",
		"sandboxUrl": "https://apx.cisco.com/spvss/infinitehome/ivptoolkit/clientrefapi/sandbox_0.4.1",
		// "sandboxUrl": "http://localhost:8090/ctap/r1.3.0",
		"redirectChannelList": "/channelList/index.html",
		"redirectVodCatalogue": "/vodCatalogue/index.html",
		"redirectstoreCategories": "/storeCategories/index.html",

//		REF API definition
		"apiCategory" : "/category",
		"apiCategories" : "/categories",
		"apiChannels" : "/channels",
		"apiContentInstances" : "/contentInstances",
		"apiPlaySession" : "/devices/me/playsessions?channelId=",
		"apiPlayVodSession" : "/devices/me/playsessions",
		"apiAggContent" : "/agg/content",

//		Icon definition
		"redIcon" : "./tokenManager/img/red-tick.png",
		"greenIcon" : "./tokenManager/img/green-tick.png",
		"orangeIcon" : "./tokenManager/img/orange-tick.png",
		"purpleIcon" : "./tokenManager/img/purple-light.png",
		"ciscoIcon" : "./tokenManager/img/ciscodev.png",

//		Link definition
		"linkLiveTv" : "./liveTV/index.html",
		"linkChannelList" : "../channelList/index.html",
		"linkVodCatalogue" : "../vodCatalogue/index.html",

//		Persistent storage definition
		"storeAccesstoken" : "accesstoken",
		"storePlaySessionID" : "playSessionID",
		"storePlayUrl" : "playUrl",
		"storeClientId" : "clientId",
		"storeRedirectUri" : "redirectUri",
		"storeRootPath" : "rootPath",
		"storeTokenStatus" : "tokenStatus",
		"storeTokenType" : "tokenType",
		"storeExpirationDate" : "expirationDate",
		"storeExpiration" : "expiration",
		"storeNeedParsing" : "needParsing",		
		"playDefault" : playBigBunny

};



//default HLS URL for Live Player
var playBigBunny="http://www.streambox.fr/playlists/x36xhzz/x36xhzz.m3u8";
var playArte="http://www.streambox.fr/playlists/test_001/stream.m3u8";
var playApple="http://devimages.apple.com/iphone/samples/bipbop/bipbopall.m3u8";
var playStarWars ="http://cdn.theoplayer.com/video/star_wars_episode_vii-the_force_awakens_official_comic-con_2015_reel_(2015)/index.m3u8";
var playTravel="http://ih-lb-vip.spvsstmedmz.cisco.com/live/lifestyle-travel/lifestyle-travel.m3u8";
var playIndian="http://live.wmncdn.net/oziindian/bbb19eae240ec100af921d511efc86a0.sdp/mono.m3u8";

var playJelly="https://wowza.jwplayer.com/live/jelly.stream/playlist.m3u8";
var playIgn="http://d19po1a6a410oc.cloudfront.net/videos/ign_channel_ibc_final/hls/multi_bitrate_playlist.m3u8";
var playBipBop="http://solutions.brightcove.com/jwhisenant/hls/apple/bipbop/bipbopall.m3u8";
var playAbc="http://abclive.abcnews.com/i/abc_live4@136330/index_1200_av-b.m3u8";
var playUfc="http://live-1112.la2.edge.filmon.com/live/713.low.stream/playlist.m3u8?id=035bca1a71b11fce016d28acd3dbea51cbc96ddfe5b9ed3f8fe3286df6a738d3a1960cc9cb3d91b7f378c16b4c5c7464e2608c9f3140573a39b54c319a2bcdb424be2e7e2a2ea454d36092c8afc5356e2ca10eacba8d757720d4b28d3aa0a053c44df298e5ea1703710ecbb5bfb71d1845147f4a738028788594af47d8dfac6013c3cafa1ae200e4ac5ad7b5261418f18420f90e5dc56dd64f67f7ec4c8756f33b2eb711b1b2a96d";
var playEurosport="http://esioslive6-i.akamaihd.net/hls/live/202892/AL_P_ESP1_FR_FRA/playlist.m3u8";
