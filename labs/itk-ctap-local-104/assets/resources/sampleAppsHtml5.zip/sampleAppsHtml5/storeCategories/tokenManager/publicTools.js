//different possible states of the authentication token
tokenStateEnum = {
		TOKEN_READY : 0,
		TOKEN_EXPIRED : 1,
		TOKEN_NOT_FOUND : 2,
		CLIENT_ID_NOT_FOUND : 3,
		ROOT_PATH_NOT_FOUND : 4
}



//This function getting a new token by calling oauth2 procedure
//The redirect_uri must be declared in Mulesoft Sandbox configuration
//corresponding to your Client ID.
function implicitGrant() {

	console.log("implicitGrant: ");
	sessionStorage.setItem(cfg.storeNeedParsing,2);
	var rootPath = sessionStorage.getItem(cfg.storeRootPath);
	if (rootPath === null) {
		var error_messageH5 = "WARNING ! You didn't enter URL yet. Please do it NOW !";
		imgUp("refapi_img", cfg.orangeIcon);
		messageH5("refapi_1", error_messageH5);
		messagemessageAlert("ID_ALERT","alertID",error_messageH5);
		return;
	}


	console.log("rootPath: " + rootPath);
	var authenticate_url = cfg.authUrl
	+ "&redirect_uri="
	+ sessionStorage.getItem(cfg.storeRedirectUri)
	+ "&client_id=" + localStorage.getItem(cfg.storeClientId);

	if ((localStorage.getItem(cfg.storeClientId) !== null)
			&& (localStorage.getItem(cfg.storeClientId) !== "undefined")) {
		console.log("authenticate_url"+ authenticate_url);

		messageH5("refapi_1", authenticate_url);
		messageH5("token_0", "CLIENT_ID = " + localStorage.getItem(cfg.storeClientId));
		window.location.href = authenticate_url;
	} else {
		var error_messageH5 = "WARNING ! You didn't enter any clientId yet";
		imgUp("refapi_img", cfg.orangeIcon);
		messageH5("refapi_1", error_messageH5);
		messagemessageAlert("ID_ALERT","alertID",error_messageH5);
	}
}


//Find the root path URL from current location
//should be call at loading
function updateRootPath() {

	var getUrl = window.location;
	var baseUrl = getUrl .protocol + "//" + getUrl.host + getUrl.pathname;
	var lastSlash=-1;
	console.log("updateRootPath "+baseUrl);

	for(var i=0;i<2;i++) {
		lastSlash=baseUrl.lastIndexOf('/');
		if(lastSlash>0) {
			baseUrl=baseUrl.substr(0,lastSlash);	
		}

	}
	sessionStorage.setItem(cfg.storeRootPath,baseUrl);
	console.log("BASE URL:"+baseUrl);
	updateStartsWith();
}


//Warning: on IE, startsWith function is NOT supported
function updateStartsWith() {

	if (!String.prototype.startsWith) {
		String.prototype.startsWith = function(searchString, position) {
			position = position || 0;
			return this.indexOf(searchString, position) === position;
		};
	}
}
//This function is in charge of parsing the URL
//the token value and expiration time are returned as URL parameters
//by oauth2 authentication procedure
function parseUrl() {
	var needParsing=0;
	if(sessionStorage.getItem(cfg.storeNeedParsing)) {
		needParsing = sessionStorage.getItem(cfg.storeNeedParsing);
	}
	console.log("parseUrl needParsing = " + 	needParsing );
	if(	needParsing <= 0 )
	{
		return;
	}


	console.log("PARSE URL in progress . . . ");
	
	var regex = /[?&#]([^=#]+)=([^&#]*)/g, url = window.location.href, parameterMap = {}, match;
	var nbMatch =0;
	needParsing--;
	sessionStorage.setItem(cfg.storeNeedParsing,needParsing);

	console.log("Current URL: " + window.location.href);


	while (match = regex.exec(url)) {
		parameterMap[match[1]] = match[2];
		console.log("Found " + match[1] + ": " + parameterMap[match[1]]);
		nbMatch++;
	}
	console.log("nbMatch: " + nbMatch);


	if(nbMatch<3 && needParsing<0) {
		console.log("removeItem: storeClientId storeAccesstoken storeExpirationDate:");
		messageAlert("ID_ALERT","GO TO removeItem to force token renew");
		localStorage.removeItem(cfg.storeClientId);
		localStorage.removeItem(cfg.storeAccesstoken);
		localStorage.removeItem(cfg.storeExpirationDate);
	} else {
		var now = new Date();
		var expirationDate = new Date();
		expirationDate.setSeconds(parameterMap.expires_in);

		localStorage.removeItem(cfg.storeTokenType);
		localStorage.removeItem(cfg.storeExpiration);
		localStorage.removeItem(cfg.storeExpirationDate);
		localStorage.removeItem(cfg.storeAccesstoken);

		localStorage.setItem(cfg.storeTokenType, parameterMap.token_type);
		localStorage.setItem(cfg.storeExpiration, parameterMap.expires_in);
		localStorage.setItem(cfg.storeExpirationDate, expirationDate.getTime());
		localStorage.setItem(cfg.storeAccesstoken, parameterMap.access_token);
		sessionStorage.setItem(cfg.storeNeedParsing,0);

		messageH5("token_1", "STATUS = A token has been received at : " + now
				+ " will expire in: " + localStorage.getItem(cfg.storeExpiration)
				+ " seconds. ");
		messageH5("token_2", "TOKEN = accesstoken:"
				+ localStorage.getItem(cfg.storeAccesstoken));
		console.log("New expirationDate: " + expirationDate);

	}

}

//This function is in charge of parsing the URL
//the token value and expiration time are returned as URL parameters
//by oauth2 authentication procedure
//This function is in charge of getting a new token by calling
//implicitGrant function
//Client ID is change if something is found in corresponding input field.
//Client ID information is stored in persistent session storage.
function myFunctionResetToken() {

	imgUp("token_img" , cfg.purpleIcon);
	imgUp("refapi_img", cfg.purpleIcon);

	messageAlert("ID_ALERT", "STATUS : Token renew in progress !");
	messageAlert("ID_COMMENT", "Please Wait ...");

	var clientId = document.getElementById("ID_CLIENTID").value;

	messageAlert("ID_COMMENT", "NEW CLIENT ID " + clientId);

	if (clientId.length > 0) {
		console.log("New CLIENT ID: " + clientId);
		localStorage.removeItem(cfg.storeClientId);
		localStorage.setItem(cfg.storeClientId, clientId);
	}


	// reset persistent token
	var rootPath = sessionStorage.getItem(cfg.storeRootPath);
	localStorage.removeItem(cfg.storeAccesstoken);
	sessionStorage.setItem(cfg.storeRedirectUri,rootPath+cfg.redirectChannelList);
	// Generate new token
	implicitGrant();
}


//This function is in charge of hiding / showing an area
//where the answer can be shown at JSON format
function myFunctionShowJSON() {
	var x = document.getElementById('ID_DISPLAY');
	if (x.style.visibility === 'hidden') {
		x.style.visibility = 'visible';
		x.style.display = "block";

	} else {
		x.style.visibility = 'hidden';
		x.style.display = "none";

		//x.style.display = "block";
	}
}

//This function is in charge of displaying a msg
//by updating the innerHTML of an element identified by its ID
function message(id, msg, mycolor,mystyle) {

	//console.log("TEXT id : "+id);
	//console.log("TEXT msg : "+msg);
	//console.log("TEXT color : "+mycolor);

	
	var x = document.getElementById(id);
	if(x !== null) {
		
		//x.style.color = mycolor;
		x.style.background = "#CCCCBB";
		x.style.border = "2px solid black";
		
		// x.style.font-size = "20px";
		
		
		if(mystyle===0) { 
			x.innerHTML =msg;			
		}
		
		if(mystyle===1) { 
			x.innerHTML = "<H1><p>" + msg + "</p></H1>";			
		}
		
		if(mystyle===2) { 
			console.log("TEXT H2: "+msg);
			x.innerHTML = "<H2><p>" + msg + "</p></H2>";			
		}
		
		if(mystyle===3) { 
			x.innerHTML = "<H3><p>" + msg + "</p></H3>";			
		}
		
		if(mystyle===4) { 
			x.innerHTML = "<H4><p>" + msg + "</p></H4>";			
		}

		if(mystyle===5) { 
			x.innerHTML = "<H5><p>" + msg + "</p></H5>";			
		}
		if(mystyle===6) { 
			x.innerHTML = "<H6><p>" + msg + "</p></H6>";			
		}
		if(mystyle===21) { 
			x.innerHTML = "<msgAlert><p>" + msg + "</p></msgAlert>";			
		}
		if(mystyle===22) { 
			x.innerHTML = "<redAlert><p>" + msg + "</p></redAlert>";			
		}
		if(mystyle===23) { 
			x.innerHTML = "<greenAlert><p>" + msg + "</p></greenAlert>";			
		}
		if(mystyle===24) { 
			x.innerHTML = "<msgLeftAlert><p>" + msg + "</p></msgLeftAlert>";			
		}
	} 
}

function messageInput(id, msg) {
	message(id,msg,"black",0);
}

function messageAlert(id, msg) {
	message(id,msg,"black",21);
}


function messageGreenAlert(id, msg) {
	message(id,msg,"green",23);
}

function messageRedAlert(id, msg) {
	message(id,msg,"red",22);
}


function messageLeftAlert(id, msg) {
	message(id,msg,"red",24);
}

//This function is in charge of displaying a msg
//by updating the innerHTML of an element identified by its ID
function messageH5(id, msg) {
	message(id,msg,"black",5);
}

//This function is in charge of displaying a msg
//by updating the innerHTML of an element identified by its ID
function messageH6(id, msg) {
	message(id,msg,"black",6);
}


function messageH3(id, msg) {
	message(id,msg,"black",3);
}

function messageH2(id, msg) {
	message(id,msg,"black",2);
}

//This function is in charge of updating icon status
//by changing the src attribute of an element identified by its ID
function imgUp(id, img) {
	if(document.getElementById(id)!== null) {
		document.getElementById(id).setAttribute("src", img);
	}
}

function errorReason(xhr, status) { // error callback
	switch (status) {
	case 403:
		messagemessageAlert("ID_ALERT","alertID",'Forbidden Access. Check your token');
		break;
	case 404:
		messageAlert("ID_ALERT",'File not found');
		break;
	case 500:
		messageAlert("ID_ALERT",'Server error');
		break;
	case 0:
		messageAlert("ID_ALERT",'Request aborted status:' + xhr.status);
		break;
	default:
		messageAlert("ID_ALERT",'Unknown error ' + status);
	break;
	}
};

//This function is in charge checking Token status
//old token value and expiration time can be retrieved for persistent session
//storage
function checkTokenStatus() {
	console.log("CHECK TOKEN STATUS in progress . . . ");
	var myDate = new Date();
	var expirationDate = new Date();

	console.log("TOKEN clientId  " + localStorage.getItem(cfg.storeClientId));
	console.log("TOKEN rootPath  " + sessionStorage.getItem(cfg.storeRootPath));

	if (localStorage.getItem(cfg.storeClientId) === null) {
		status = tokenStateEnum.CLIENT_ID_NOT_FOUND;
	} else {
		if (sessionStorage.getItem(cfg.storeRootPath) === null) {
			status = tokenStateEnum.ROOT_PATH_NOT_FOUND;
		} else {
			if ((localStorage.getItem(cfg.storeAccesstoken) !== null)
					&& (localStorage.getItem(cfg.storeAccesstoken) !== "undefined")) {
				var expiration = localStorage.getItem(cfg.storeExpirationDate);
				var delta = (expiration - myDate.getTime()) / 1000;
				expirationDate.setTime(expiration);
				console.log("Expiration date 2: " + expirationDate);
				console.log("Delta: " + delta);
				if (delta > 0) {
					status = tokenStateEnum.TOKEN_READY;
					if(delta > 3580) {
						status = tokenStateEnum.CLIENT_ID_NOT_FOUND;
					}

				} else {
					status = tokenStateEnum.TOKEN_EXPIRED;
				}
			} else {
				status = tokenStateEnum.TOKEN_NOT_FOUND;
			}
		}
	}
	console.log("TOKEN STATUS " + status);

	sessionStorage.removeItem(cfg.storeTokenStatus);
	sessionStorage.setItem(cfg.storeTokenStatus, status);
	console.log("TOKEN STATUS STORE " + sessionStorage.getItem(cfg.storeTokenStatus));

	return expirationDate;
}


function 	fillAttribute(comp,target) {

for (var k in target){	


	// Test if k is Object to display or Array to browse
	
	if (typeof target[k]  === 'object') {
		var itemList = target[k];
		
		var divMediaTitle = document.createElement('input');
		divMediaTitle.setAttribute("class", "form-control");
		divMediaTitle.setAttribute("style", "background:#CCEEBB");
		divMediaTitle.value=k;
		comp.appendChild(divMediaTitle);
				
		for (var m in itemList){

			if (itemList.hasOwnProperty(m) && typeof itemList[m]!=='object') {
				var divMediaTitle = document.createElement('input');
				divMediaTitle.setAttribute("class", "form-control");
				divMediaTitle.setAttribute("style", "background:#CCBBBB");
				divMediaTitle.value=m;
				comp.appendChild(divMediaTitle);
				
				var divMediaText = document.createElement('input');
				divMediaText.setAttribute("class", "form-control");
				divMediaText.value=itemList[m];
				comp.appendChild(divMediaText);
			} else {
				fillAttribute(comp,itemList[m]);
				}
			}
		} else {
			
			if (target.hasOwnProperty(k) ) {
				var divMediaTitle = document.createElement('input');
				divMediaTitle.setAttribute("class", "form-control");
				divMediaTitle.setAttribute("style", "background:#CCBBBB");
				divMediaTitle.value=k;
				comp.appendChild(divMediaTitle);
				
				var divMediaText = document.createElement('input');
				divMediaText.setAttribute("class", "form-control");
				divMediaText.value=target[k];
				comp.appendChild(divMediaText);
			}			
			
		}

	}
}	
	

function checkConfig(redirectUri, callback) {

	var expDate = checkTokenStatus();
	var tokenState = sessionStorage.getItem(cfg.storeTokenStatus);
	console.log("tokenState :"+tokenState);
	console.log("expDate :"+expDate);
	messageInput("ID_CLIENTID", localStorage.getItem(cfg.storeClientId));

	switch (parseInt(tokenState)) {


	case tokenStateEnum.TOKEN_READY:
		messageAlert("ID_COMMENT",
				"A valid token is available. It will expire at " + expDate);

		messageAlert("ID_EXPDATE", expDate);	

		messageAlert("ID_TOKEN", 
				"Access Token: " + localStorage.getItem(cfg.storeAccesstoken));


		imgUp("token_img", cfg.greenIcon);
		messageGreenAlert("ID_ALERT", "TOKEN IS READY");
		callback();

		break;

	case tokenStateEnum.TOKEN_EXPIRED:
		var error_msg = "TOKEN EXPIRED since " + expDate;
		var rootPath = sessionStorage.getItem(cfg.storeRootPath);
		messageRedAlert("ID_ALERT",error_msg);
		messageAlert("ID_COMMENT", " Please press 'Reset Token' button to get a new token.");

		sessionStorage.setItem(cfg.storeRedirectUri, rootPath+redirectUri );
		console.log("Redirect Uri for channel list:"+sessionStorage.getItem(cfg.storeRedirectUri));
		imgUp("token_img", cfg.orangeIcon);
		// implicitGrant();
		$('#collapse1').collapse();

		break;

	case tokenStateEnum.TOKEN_NOT_FOUND:
		messageRedAlert("ID_ALERT", "TOKEN NOT FOUND");	
		var msg = "In order to get a valid Token, an OAuth2 authentication process is performed. <br>A redirect URI is mandatory. Check that redirect URI is this one: "+cfg.storeRedirectUri+"<br>Please get more information by clicking Oauth2 info button</br>"		
		messageAlert("ID_COMMENT", 	msg);
		imgUp("token_img", cfg.redIcon);
		$('#collapse1').collapse();
		break;

	case tokenStateEnum.CLIENT_ID_NOT_FOUND:
		messageRedAlert("ID_ALERT", "CLIENT ID NOT FOUND");
		var msg = "In order to use the REF API, a Client ID is mandatory.";
		msg+="<br>To get that Client ID a registration on MuleSoft portal is necessary.";
		msg+="<br>Please get more information by clicking 'OAuth2 info' button</br> ";
		msg+="<br>Once you get a Client ID, enter it in Client ID field and press 'Reset Token' button";

		messageAlert("ID_COMMENT", msg);		
		imgUp("token_img", cfg.redIcon);
		$('#collapse1').collapse();

		break;


	case tokenStateEnum.ROOT_PATH_NOT_FOUND:
		// serious issue found. Go to Token manager app to fix it
		//window.location.href=cfg.linkTokenManager;
		$('#collapse1').collapse();
		break;

	default:
		console.log("CASE BAD VALUE: " + tokenState);
	$('#collapse1').collapse();
	break;

	}
}



function addToogleIcon(name) {

	var toggle = document.getElementById(name);
	var tokenImg = document.getElementById("token_img");
	if(toggle && !tokenImg) {
		var elem = document.createElement('img');
		elem.setAttribute("id", "token_img");
		elem.setAttribute("src", cfg.purpleIcon);
		elem.setAttribute("height", "40");
		elem.setAttribute("width", "40");
		elem.setAttribute("hspace", "40");
		toggle.appendChild(elem);
	}

}
